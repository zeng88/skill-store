---
name: agnes-image-generation
description: Call Agnes AI image generation API (agnes-image-2.1-flash) for text-to-image and image-to-image. Use when the user asks to generate images, edit images, create visual content with Agnes, or use Agnes Image 2.1 Flash model.
---

# Agnes Image Generation

Use this skill to call Agnes AI image generation API through `https://apihub.agnes-ai.com`.

Model: `agnes-image-2.1-flash` — free, high-quality image generation by Sapiens AI.

## Quick Start

1. Read `references/api.md` when endpoint details, parameters, or response fields are needed.
2. Use `scripts/agnes_image.py` for all API calls instead of writing curl by hand.
3. Require an API key in `AGNES_API_KEY`, `AGNES_API_TOKEN`, or `APIHUB_AGNES_API_KEY`. Never print the key.

## Setup (one time)

```bash
# Set your API key (get it from https://agnes-ai.com)
export AGNES_API_KEY="sk-your-key-here"
```

## Commands

### Text-to-Image

```bash
python scripts/agnes_image.py generate --prompt "A floating city above misty canyon at sunrise, cinematic" --size 1024x768
```

### Image-to-Image (editing)

```bash
python scripts/agnes_image.py edit --prompt "Transform into rainy cyberpunk night" --image /Users/me/Desktop/input.png --preserve "main subject identity, face, pose, and composition" --size 1024x768
```

### Image-to-Image With Public URL

```bash
python scripts/agnes_image.py edit --prompt "Transform into rainy cyberpunk night" --image https://example.com/input.png --preserve "main subject identity and composition" --size 1024x768
```

### With Chinese Prompt (auto-translated)

```bash
python scripts/agnes_image.py generate --prompt "一只柴犬在樱花树下微笑，日系清新风格"
```

### Advanced: Custom Extra Body

```bash
python scripts/agnes_image.py generate --prompt "Your prompt" --size 1024x1024 --response-format b64_json
```

## Workflow

- Prefer `agnes-image-2.1-flash` for all text-to-image and image-to-image tasks.
- For image generation, convert any non-English user prompt to a fluent English generation prompt before calling the API. English prompts are more stable. Preserve concrete visual details, style, lighting, composition, and constraints during translation.
- High-density image generation is prompt-driven: include subject hierarchy, environment, secondary details, lighting, composition, and quality requirements.
- For image-to-image, include what to change AND what to preserve (composition, main subjects, etc.) in the prompt or `--preserve`.
- `--image` accepts public URLs, data URLs, and local file paths. Local files are converted to data URLs client-side before the API request.
- Use `--seed` when you want more reproducible outputs across repeated runs.

## Prompt Formula

```
[Subject] + [Scene / Environment] + [Style] + [Lighting] + [Composition] + [Quality Requirements]
```

Good example:
> A luminous floating city above a misty canyon at sunrise, cinematic realism, wide-angle composition, rich architectural details, soft golden light, high visual density

## Output Handling

- Image responses return URLs by default (via `extra_body.response_format: url`).
- Extract image URLs from the `url` field in response `data[]` items.
- Save or display the returned image URL to the user.
- If a request fails, report HTTP status and provider error body without exposing the API key.

## Capabilities

| Capability | Description |
|-----------|-------------|
| Text-to-Image | Generate high-quality images from natural language prompts |
| Image-to-Image | Transform or enhance existing images based on prompts |
| Local Reference Image Input | Accept local file paths and convert them client-side for image-to-image requests |
| High-Density Optimization | Better handle detailed, visually complex images |
| Composition Preservation | Maintain original composition when editing images |
| Flexible Sizes | Support custom output sizes (e.g., 1024x768) |
| URL Response | Return results as accessible URLs |

## Notes

- This workflow is reference-guided regeneration, not pixel-locked editing.
- The provider documentation publicly documents URL-based image inputs. This skill also supports local files by converting them into data URLs client-side. If the provider rejects data URLs, the request will fail with the provider error instead of silently downgrading behavior.
