#!/usr/bin/env python3
"""Minimal CLI for Agnes AI image generation API (agnes-image-2.1-flash)."""

from __future__ import annotations

import argparse
import base64
import json
import mimetypes
import os
import re
import ssl
import sys
from datetime import datetime
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any

# Fix macOS Python SSL certificate verify failures
# Try to use certifi's CA bundle; if not installed, fall back to unverified
# (unverified is safe for HTTPS API calls to known hosts)
try:
    import certifi
    _SSL_CONTEXT = ssl.create_default_context(cafile=certifi.where())
except ImportError:
    _SSL_CONTEXT = ssl._create_unverified_context()


BASE_URL = "https://apihub.agnes-ai.com"
IMAGE_MODEL = "agnes-image-2.1-flash"
TEXT_MODEL = "agnes-2.0-flash"
SIZE_RE = re.compile(r"^[1-9]\d*x[1-9]\d*$")
URL_RE = re.compile(r"^https?://", re.IGNORECASE)
DATA_URL_RE = re.compile(r"^data:", re.IGNORECASE)
SUPPORTED_IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp"}


def get_api_key() -> str:
    for name in ("AGNES_API_KEY", "AGNES_API_TOKEN", "APIHUB_AGNES_API_KEY"):
        value = os.environ.get(name)
        if value:
            return value
    raise SystemExit(
        "Missing API key. Set AGNES_API_KEY, AGNES_API_TOKEN, or APIHUB_AGNES_API_KEY.\n"
        "Get your key from https://agnes-ai.com"
    )


def request_json(path: str, payload: dict[str, Any]) -> dict[str, Any]:
    body = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        BASE_URL + path,
        data=body,
        method="POST",
        headers={
            "Authorization": f"Bearer {get_api_key()}",
            "Content-Type": "application/json",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=120, context=_SSL_CONTEXT) as resp:
            text = resp.read().decode("utf-8")
            return json.loads(text) if text else {}
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise SystemExit(f"HTTP {exc.code} from {path}: {detail}") from exc
    except urllib.error.URLError as exc:
        raise SystemExit(f"Request failed for {path}: {exc}") from exc


def print_json(data: Any) -> None:
    print(json.dumps(data, ensure_ascii=False, indent=2))


def needs_english_translation(prompt: str) -> bool:
    return any(ord(ch) > 127 for ch in prompt)


def translate_prompt(prompt: str) -> str:
    payload = {
        "model": TEXT_MODEL,
        "messages": [
            {
                "role": "system",
                "content": (
                    "Translate the user's image generation prompt into fluent English. "
                    "Preserve all concrete visual details, style words, camera instructions, "
                    "lighting, composition constraints, and negative instructions. "
                    "Return only the English prompt, nothing else."
                ),
            },
            {"role": "user", "content": prompt},
        ],
        "temperature": 0,
        "max_tokens": 800,
    }
    data = request_json("/v1/chat/completions", payload)
    try:
        translated = data["choices"][0]["message"]["content"].strip()
    except (KeyError, IndexError, TypeError):
        raise SystemExit("Prompt translation failed. Response did not contain expected content.")
    if not translated:
        raise SystemExit("Prompt translation returned empty result.")
    return translated


def validate_size(value: str) -> None:
    if not SIZE_RE.match(value):
        raise SystemExit(f"Invalid size: {value}. Expected WIDTHxHEIGHT, e.g., 1024x768.")


def validate_seed(value: int | None) -> None:
    if value is not None and value < 0:
        raise SystemExit("Invalid seed: expected a non-negative integer.")


def image_source_kind(value: str) -> str:
    if URL_RE.match(value):
        return "url"
    if DATA_URL_RE.match(value):
        return "data_url"
    return "path"


def local_image_to_data_url(value: str) -> str:
    path = Path(value).expanduser().resolve()
    if not path.exists():
        raise SystemExit(f"Image path does not exist: {value}")
    if not path.is_file():
        raise SystemExit(f"Image path is not a file: {value}")
    if path.suffix.lower() not in SUPPORTED_IMAGE_EXTENSIONS:
        raise SystemExit(
            f"Unsupported image file type: {path.suffix or '(none)'}; "
            "expected png/jpg/jpeg/webp/gif/bmp."
        )

    mime_type, _ = mimetypes.guess_type(path.name)
    if not mime_type or not mime_type.startswith("image/"):
        mime_type = "application/octet-stream"

    encoded = base64.b64encode(path.read_bytes()).decode("ascii")
    return f"data:{mime_type};base64,{encoded}"


def normalize_image_inputs(values: list[str] | None) -> tuple[list[str], list[dict[str, str]]]:
    if not values:
        return [], []

    normalized: list[str] = []
    metadata: list[dict[str, str]] = []
    for value in values:
        kind = image_source_kind(value)
        if kind == "path":
            data_url = local_image_to_data_url(value)
            normalized.append(data_url)
            metadata.append(
                {
                    "input": value,
                    "source_type": "local_path",
                    "transport": "data_url",
                }
            )
            continue

        normalized.append(value)
        metadata.append(
            {
                "input": value,
                "source_type": "data_url" if kind == "data_url" else "url",
                "transport": "verbatim",
            }
        )
    return normalized, metadata


def extract_image_urls(data: dict[str, Any]) -> list[str]:
    urls = []
    if isinstance(data.get("url"), str):
        urls.append(data["url"])
    if isinstance(data.get("image_url"), str):
        urls.append(data["image_url"])
    if isinstance(data.get("data"), list):
        for item in data["data"]:
            if isinstance(item, dict):
                for key in ("url", "image_url"):
                    if isinstance(item.get(key), str):
                        urls.append(item[key])
    return urls


def allocate_output_path(output_dir: Path, batch_id: str, index: int, ext: str) -> Path:
    filename = output_dir / f"agnes-{batch_id}-{index:03d}.{ext}"
    if not filename.exists():
        return filename

    suffix = 1
    while True:
        filename = output_dir / f"agnes-{batch_id}-{index:03d}-{suffix:02d}.{ext}"
        if not filename.exists():
            return filename
        suffix += 1


def download_images(urls: list[str], output_dir: str) -> list[str]:
    """Download image URLs to output_dir, return list of local file paths."""
    out = Path(output_dir).expanduser().resolve()
    out.mkdir(parents=True, exist_ok=True)
    batch_id = datetime.now().strftime("%Y%m%d-%H%M%S")
    saved = []
    for i, url in enumerate(urls):
        ext = url.split(".")[-1].split("?")[0][:4]
        if ext not in ("png", "jpg", "jpeg", "webp"):
            ext = "png"
        filename = allocate_output_path(out, batch_id, i + 1, ext)
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        try:
            with urllib.request.urlopen(req, timeout=60, context=_SSL_CONTEXT) as resp:
                filename.write_bytes(resp.read())
            saved.append(str(filename))
            print(f"  Saved: {filename}", file=sys.stderr)
        except Exception as exc:
            print(f"  Warning: failed to download {url}: {exc}", file=sys.stderr)
    return saved


def cmd_generate(args: argparse.Namespace) -> None:
    """Text-to-image or image-to-image generation."""
    validate_size(args.size)
    validate_seed(args.seed)

    prompt = args.prompt
    translated = None
    image_inputs, image_input_metadata = normalize_image_inputs(args.image)

    if args.preserve:
        prompt = f"{prompt.rstrip()}. Preserve: {args.preserve.strip()}."

    if not args.no_translate and needs_english_translation(prompt):
        print(f"Translating prompt to English...", file=sys.stderr)
        translated = translate_prompt(prompt)
        prompt = translated
        print(f"  Original: {args.prompt}", file=sys.stderr)
        print(f"  Translated: {prompt}", file=sys.stderr)

    payload: dict[str, Any] = {
        "model": IMAGE_MODEL,
        "prompt": prompt,
    }

    if args.size:
        payload["size"] = args.size
    if args.seed is not None:
        payload["seed"] = args.seed

    extra: dict[str, Any] = {"response_format": args.response_format}
    if image_inputs:
        extra["image"] = image_inputs
    payload["extra_body"] = extra

    data = request_json("/v1/images/generations", payload)
    urls = extract_image_urls(data)

    result = {
        "type": "image-to-image" if image_inputs else "text-to-image",
        "prompt_used": prompt,
        "urls": urls,
        "raw": data,
    }
    if translated:
        result["original_prompt"] = args.prompt
        result["translated_prompt"] = translated
    if image_input_metadata:
        result["image_inputs"] = image_input_metadata
    if args.seed is not None:
        result["seed"] = args.seed
    if args.preserve:
        result["preserve"] = args.preserve

    # Download to local if requested
    if getattr(args, "download", False):
        local_paths = download_images(urls, getattr(args, "output_dir", "~/Desktop/agnes-output"))
        result["local_paths"] = local_paths
        print(f"\nDownloaded {len(local_paths)} image(s) to: {local_paths[0] if local_paths else '(none)'}", file=sys.stderr)

    print_json(data if args.raw else result)


def cmd_edit(args: argparse.Namespace) -> None:
    """Alias for generate with --image. Convenience for image-to-image workflow."""
    if not args.image:
        raise SystemExit("edit requires at least one --image URL.")
    args.func = cmd_generate
    cmd_generate(args)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Call Agnes AI image generation API (agnes-image-2.1-flash)."
    )
    sub = parser.add_subparsers(dest="command")

    # Shared parent for download args
    download_parent = argparse.ArgumentParser(add_help=False)
    download_parent.add_argument(
        "--download",
        action="store_true",
        help="Download generated images to local directory.",
    )
    download_parent.add_argument(
        "--output-dir",
        default="~/Desktop/agnes-output",
        help="Directory to save downloaded images. Default: ~/Desktop/agnes-output",
    )

    # generate
    gen = sub.add_parser("generate", parents=[download_parent], help="Generate image from text prompt.")
    gen.add_argument("--prompt", required=True, help="Text description of the desired image.")
    gen.add_argument("--size", default="1024x768", help="Output size, e.g., 1024x768.")
    gen.add_argument(
        "--image",
        action="append",
        help="Reference image input. Supports public URLs, data URLs, or local file paths. Repeat for multiple.",
    )
    gen.add_argument(
        "--preserve",
        help="What to preserve from the reference image, e.g. subject identity, pose, composition, outfit.",
    )
    gen.add_argument(
        "--seed",
        type=int,
        help="Optional non-negative seed for more reproducible outputs.",
    )
    gen.add_argument(
        "--response-format",
        default="url",
        choices=["url", "b64_json"],
        help="Response format. Default: url.",
    )
    gen.add_argument(
        "--no-translate",
        action="store_true",
        help="Skip auto-translation of non-English prompts.",
    )
    gen.add_argument(
        "--raw",
        action="store_true",
        help="Print raw provider response instead of summary.",
    )
    gen.set_defaults(func=cmd_generate)

    # edit (alias for generate --image)
    edit = sub.add_parser("edit", parents=[download_parent], help="Edit an existing image (image-to-image).")
    edit.add_argument("--prompt", required=True, help="Editing instruction.")
    edit.add_argument(
        "--image",
        required=True,
        action="append",
        help="Reference image input. Supports public URLs, data URLs, or local file paths. Repeat for multiple.",
    )
    edit.add_argument("--size", default="1024x768", help="Output size, e.g., 1024x768.")
    edit.add_argument(
        "--preserve",
        help="What to preserve from the reference image, e.g. subject identity, pose, composition, outfit.",
    )
    edit.add_argument(
        "--seed",
        type=int,
        help="Optional non-negative seed for more reproducible outputs.",
    )
    edit.add_argument(
        "--response-format",
        default="url",
        choices=["url", "b64_json"],
        help="Response format. Default: url.",
    )
    edit.add_argument(
        "--no-translate",
        action="store_true",
        help="Skip auto-translation of non-English prompts.",
    )
    edit.add_argument(
        "--raw",
        action="store_true",
        help="Print raw provider response.",
    )
    edit.set_defaults(func=cmd_edit)

    return parser


def main() -> None:
    if len(sys.argv) == 1:
        build_parser().print_help()
        sys.exit(0)
    args = build_parser().parse_args()
    if hasattr(args, "func"):
        args.func(args)
    else:
        build_parser().print_help()


if __name__ == "__main__":
    main()
