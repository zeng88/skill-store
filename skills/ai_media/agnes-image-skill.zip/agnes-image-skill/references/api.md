# Agnes Image API Reference

Base host: `https://apihub.agnes-ai.com`

Authentication: `Authorization: Bearer YOUR_API_KEY`

Content type: `application/json`

## Image Generation

Endpoint: `POST /v1/images/generations`

Model: `agnes-image-2.1-flash`

### Request Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `model` | string | Yes | Fixed as `agnes-image-2.1-flash` |
| `prompt` | string | Yes | Text instruction for image generation or editing |
| `size` | string | No | Output size, e.g., `1024x768` |
| `seed` | number | No | Non-negative random seed for more reproducible results |
| `extra_body` | object | No | Additional parameters |
| `extra_body.image` | array | No | Input reference images for image-to-image. Official docs publicly show URL inputs. This skill can also send local files as data URLs client-side. |
| `extra_body.response_format` | string | No | Response format: `url` or `b64_json` |

### Text-to-Image Example

Request:
```bash
curl https://apihub.agnes-ai.com/v1/images/generations \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "agnes-image-2.1-flash",
    "prompt": "A luminous floating city above a misty canyon at sunrise, cinematic realism",
    "size": "1024x768",
    "extra_body": {
      "response_format": "url"
    }
  }'
```

Expected response:
```json
{
  "data": [
    {
      "url": "https://cdn.agnes-ai.com/generated/xxx.png"
    }
  ]
}
```

### Image-to-Image Example

Request:
```bash
curl https://apihub.agnes-ai.com/v1/images/generations \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "agnes-image-2.1-flash",
    "prompt": "Transform into rainy cyberpunk night, preserve composition",
    "size": "1024x768",
    "extra_body": {
      "image": ["https://example.com/input.png"],
      "response_format": "url"
    }
  }'
```

### Local File Reference Example

The local CLI wrapper supports local file paths by converting them to data URLs before sending the request:

```bash
python scripts/agnes_image.py edit \
  --prompt "Turn this into a cinematic rainy-night portrait" \
  --image /Users/me/Desktop/reference.png \
  --preserve "face identity, hairstyle, outfit silhouette, and camera angle" \
  --seed 42 \
  --size 1024x768
```

## Prompt Writing Guide

### Formula

```
[Subject] + [Scene/Environment] + [Style] + [Lighting] + [Composition] + [Quality Requirements]
```

### Good Examples

Text-to-Image:
> A luminous floating city above a misty canyon at sunrise, cinematic realism, wide-angle composition, rich architectural details, soft golden light, high visual density

Image-to-Image:
> Transform the scene into a rain-soaked cyberpunk night with neon reflections while preserving the original composition and main subject layout

High-Density Scene:
> A futuristic city marketplace filled with flying vehicles, holographic signs, dense crowds, neon lighting, cinematic realism, ultra-detailed, high-information-density composition

### Tips

- For non-English prompts, translate to English before sending (the CLI does this automatically).
- For image-to-image: clearly state **what to change** AND **what to preserve**.
- `--preserve` appends preservation constraints to the prompt in a consistent format.
- `--image` in the CLI accepts public URLs, local file paths, and prebuilt data URLs.
- Include style keywords: `cinematic`, `photorealistic`, `illustration`, `3D render`, `anime`, `oil painting`, etc.
- Add quality modifiers: `high detail`, `8K`, `sharp focus`, `professional lighting`.

## Capabilities

| Capability | Description |
|-----------|-------------|
| Text-to-Image | Generate images from natural language prompts |
| Image-to-Image | Transform or enhance existing images based on prompts |
| Local Path Compatibility | Convert local reference files to data URLs client-side |
| High-Density Optimization | Better handle detailed, visually complex images |
| Composition Preservation | Maintain original composition when editing images |
| Flexible Sizes | Support custom output sizes |
| URL Response | Return results as accessible URLs |

## Compatibility Note

- Official Agnes documentation that is publicly available shows `extra_body.image` as URL-based input.
- This skill extends the CLI to accept local files by converting them to `data:` URLs before the request.
- If the provider rejects data URLs for a given account, model version, or deployment environment, the API will return an error and the CLI will surface that error directly.

## Error Codes

| Code | Meaning |
|------|---------|
| `400` | Invalid request — check parameters |
| `401` | Unauthorized — check API key |
| `500` | Server error — retry later |
| `503` | Service busy — retry later |

## Pricing

**Free** as of June 1, 2026. Originally $0.003/image.

## References

- Official docs: https://agnes-ai.com/doc/agnes-image-21-flash
- Skill repo: https://github.com/Yacey/agnes-ai-generation-skill
