# Agnes Image Skill

基于 Agnes AI `agnes-image-2.1-flash` 模型的图片生成 skill，支持：

- 文生图
- 图生图
- 本地参考图输入
- 公开 URL 参考图输入
- 中文提示词自动翻译为英文
- 结果 URL 返回
- 结果自动下载到本地
- 多参考图输入
- `seed` 复现控制
- `preserve` 保留约束
- 下载文件唯一命名，重复执行不覆盖旧图

适用文件：

- [SKILL.md](/Users/zeng88/Desktop/agnes-image-skill/SKILL.md)
- [scripts/agnes_image.py](/Users/zeng88/Desktop/agnes-image-skill/scripts/agnes_image.py)
- [references/api.md](/Users/zeng88/Desktop/agnes-image-skill/references/api.md)

## 0. 系统兼容性

本 README 现在同时适用于：

- macOS
- Windows

命令差异主要在这几处：

- macOS 常用 `python3`
- Windows 常用 `py` 或 `python`
- macOS 路径示例通常是 `/Users/name/...`
- Windows 路径示例通常是 `C:\Users\name\...`
- macOS/Linux 环境变量使用 `export`
- Windows PowerShell 环境变量使用 `$env:...=...`

为避免命令无效，下面大多数示例都同时给出 macOS 和 Windows 写法。

## 1. 功能说明

这个 skill 封装了 Agnes 图片生成接口：

- 接口地址：`https://apihub.agnes-ai.com/v1/images/generations`
- 图片模型：`agnes-image-2.1-flash`
- 文本翻译模型：`agnes-2.0-flash`

核心能力：

- 文生图：只传 `--prompt`
- 图生图：传 `--prompt` + `--image`
- 本地参考图：`--image /local/path/to/image.png`
- URL 参考图：`--image https://example.com/image.png`
- 多图参考：重复传多个 `--image`
- 本地保存：加 `--download`
- 下载文件名按“时间戳批次 + 序号”生成，不覆盖旧文件

## 2. 输入方式

`--image` 支持以下三种输入：

- 公开 URL
- 本地图片路径
- 已构造好的 `data:` URL

本地路径会在脚本内转换成 `data:` URL 再发给 Agnes API。

支持的本地文件类型：

- `.png`
- `.jpg`
- `.jpeg`
- `.webp`
- `.gif`
- `.bmp`

## 3. 环境准备

先设置 API Key。

### macOS

```bash
export AGNES_API_KEY="sk-your-key-here"
```

### Windows PowerShell

```powershell
$env:AGNES_API_KEY="sk-your-key-here"
```

也支持以下环境变量名：

- `AGNES_API_KEY`
- `AGNES_API_TOKEN`
- `APIHUB_AGNES_API_KEY`

## 4. 基本命令

推荐先进入 skill 目录再执行命令，这样 macOS 和 Windows 都更稳定。

### macOS

```bash
cd /Users/zeng88/Desktop/agnes-image-skill
python3 scripts/agnes_image.py --help
```

### Windows PowerShell

```powershell
cd C:\Users\YourName\Desktop\agnes-image-skill
py scripts\agnes_image.py --help
```

如果你不切目录，也可以直接写脚本完整路径。

### macOS 直接执行

```bash
python3 /Users/zeng88/Desktop/agnes-image-skill/scripts/agnes_image.py --help
```

### Windows 直接执行

```powershell
py C:\Users\YourName\Desktop\agnes-image-skill\scripts\agnes_image.py --help
```

查看图生图帮助。

### macOS

```bash
python3 scripts/agnes_image.py edit --help
```

### Windows PowerShell

```powershell
py scripts\agnes_image.py edit --help
```

查看文生图帮助。

### macOS

```bash
python3 scripts/agnes_image.py generate --help
```

### Windows PowerShell

```powershell
py scripts\agnes_image.py generate --help
```

## 4.1 最短可复制命令速查表

### 文生图

macOS:

```bash
python3 scripts/agnes_image.py generate --prompt "A cinematic portrait in neon rain"
```

Windows PowerShell:

```powershell
py scripts\agnes_image.py generate --prompt "A cinematic portrait in neon rain"
```

### 中文文生图

macOS:

```bash
python3 scripts/agnes_image.py generate --prompt "一个霓虹雨夜里的电影感人像"
```

Windows PowerShell:

```powershell
py scripts\agnes_image.py generate --prompt "一个霓虹雨夜里的电影感人像"
```

### 图生图：本地参考图

macOS:

```bash
python3 scripts/agnes_image.py edit --prompt "Turn this into a cinematic portrait" --image /Users/zeng88/Desktop/ref.png
```

Windows PowerShell:

```powershell
py scripts\agnes_image.py edit --prompt "Turn this into a cinematic portrait" --image "C:\Users\YourName\Desktop\ref.png"
```

### 图生图：公开 URL 参考图

macOS:

```bash
python3 scripts/agnes_image.py edit --prompt "Turn this into a cinematic portrait" --image https://example.com/ref.png
```

Windows PowerShell:

```powershell
py scripts\agnes_image.py edit --prompt "Turn this into a cinematic portrait" --image https://example.com/ref.png
```

### 图生图：保留主体和构图

macOS:

```bash
python3 scripts/agnes_image.py edit --prompt "Turn this into a cinematic portrait" --image /Users/zeng88/Desktop/ref.png --preserve "face identity and composition"
```

Windows PowerShell:

```powershell
py scripts\agnes_image.py edit --prompt "Turn this into a cinematic portrait" --image "C:\Users\YourName\Desktop\ref.png" --preserve "face identity and composition"
```

### 多参考图

macOS:

```bash
python3 scripts/agnes_image.py edit --prompt "Combine these into one scene" --image /Users/zeng88/Desktop/a.png --image /Users/zeng88/Desktop/b.png
```

Windows PowerShell:

```powershell
py scripts\agnes_image.py edit --prompt "Combine these into one scene" --image "C:\Users\YourName\Desktop\a.png" --image "C:\Users\YourName\Desktop\b.png"
```

### 生成后下载到本地

macOS:

```bash
python3 scripts/agnes_image.py generate --prompt "A luxury product ad photo" --download
```

Windows PowerShell:

```powershell
py scripts\agnes_image.py generate --prompt "A luxury product ad photo" --download
```

下载后的文件名示例：

- `agnes-20260607-154210-001.png`
- `agnes-20260607-154210-002.png`

如果同一秒内再次生成，脚本也会自动追加后缀，避免覆盖之前的图片。

### 图生图并下载到本地

macOS:

```bash
python3 scripts/agnes_image.py edit --prompt "Turn this into a fantasy poster" --image /Users/zeng88/Desktop/ref.png --download
```

Windows PowerShell:

```powershell
py scripts\agnes_image.py edit --prompt "Turn this into a fantasy poster" --image "C:\Users\YourName\Desktop\ref.png" --download
```

### 指定下载目录

macOS:

```bash
python3 scripts/agnes_image.py generate --prompt "A glass sculpture in a gallery" --download --output-dir /Users/zeng88/Desktop/agnes-output
```

Windows PowerShell:

```powershell
py scripts\agnes_image.py generate --prompt "A glass sculpture in a gallery" --download --output-dir "C:\Users\YourName\Desktop\agnes-output"
```

### 固定 seed

macOS:

```bash
python3 scripts/agnes_image.py edit --prompt "Turn this into a cinematic portrait" --image /Users/zeng88/Desktop/ref.png --seed 42
```

Windows PowerShell:

```powershell
py scripts\agnes_image.py edit --prompt "Turn this into a cinematic portrait" --image "C:\Users\YourName\Desktop\ref.png" --seed 42
```

### 输出原始 JSON

macOS:

```bash
python3 scripts/agnes_image.py generate --prompt "A futuristic skyline" --raw
```

Windows PowerShell:

```powershell
py scripts\agnes_image.py generate --prompt "A futuristic skyline" --raw
```

### 返回 Base64

macOS:

```bash
python3 scripts/agnes_image.py generate --prompt "A studio still life" --response-format b64_json
```

Windows PowerShell:

```powershell
py scripts\agnes_image.py generate --prompt "A studio still life" --response-format b64_json
```

## 4.2 按场景分类速查表

### 人像改风格

把参考图改成电影感、杂志感、二次元、油画风：

macOS:

```bash
python3 scripts/agnes_image.py edit \
  --prompt "Turn this into a cinematic editorial portrait with dramatic lighting" \
  --image /Users/zeng88/Desktop/portrait.png \
  --preserve "face identity, hairstyle, and composition"
```

Windows PowerShell:

```powershell
py scripts\agnes_image.py edit `
  --prompt "Turn this into a cinematic editorial portrait with dramatic lighting" `
  --image "C:\Users\YourName\Desktop\portrait.png" `
  --preserve "face identity, hairstyle, and composition"
```

### 保脸保构图重生成

适合“换风格，但尽量别变人”和“保留构图”：

macOS:

```bash
python3 scripts/agnes_image.py edit \
  --prompt "Restyle this into a luxury fashion campaign image" \
  --image /Users/zeng88/Desktop/portrait.png \
  --preserve "face identity, pose, camera angle, and composition" \
  --seed 42
```

Windows PowerShell:

```powershell
py scripts\agnes_image.py edit `
  --prompt "Restyle this into a luxury fashion campaign image" `
  --image "C:\Users\YourName\Desktop\portrait.png" `
  --preserve "face identity, pose, camera angle, and composition" `
  --seed 42
```

### 商品图生成

适合做电商图、广告图、主视觉：

macOS:

```bash
python3 scripts/agnes_image.py generate \
  --prompt "A premium skincare bottle on reflective stone, luxury advertising, soft shadows, studio lighting" \
  --size 1024x1024
```

Windows PowerShell:

```powershell
py scripts\agnes_image.py generate `
  --prompt "A premium skincare bottle on reflective stone, luxury advertising, soft shadows, studio lighting" `
  --size 1024x1024
```

### 海报生成

适合做电影海报、活动海报、宣传视觉：

macOS:

```bash
python3 scripts/agnes_image.py generate \
  --prompt "A fantasy movie poster with heroic character, golden backlight, epic atmosphere, cinematic composition" \
  --size 1024x1536
```

Windows PowerShell:

```powershell
py scripts\agnes_image.py generate `
  --prompt "A fantasy movie poster with heroic character, golden backlight, epic atmosphere, cinematic composition" `
  --size 1024x1536
```

### 单张参考图重绘

按一张参考图重新生成新图：

macOS:

```bash
python3 scripts/agnes_image.py edit \
  --prompt "Turn this into a futuristic neon-night scene" \
  --image /Users/zeng88/Desktop/ref.png
```

Windows PowerShell:

```powershell
py scripts\agnes_image.py edit `
  --prompt "Turn this into a futuristic neon-night scene" `
  --image "C:\Users\YourName\Desktop\ref.png"
```

### 双图融合

适合把两个人物、两张设定图或两张风格图融合成一个画面：

macOS:

```bash
python3 scripts/agnes_image.py edit \
  --prompt "Combine these two characters into one dynamic duel scene" \
  --image /Users/zeng88/Desktop/char-a.png \
  --image /Users/zeng88/Desktop/char-b.png \
  --preserve "both character identities and overall framing"
```

Windows PowerShell:

```powershell
py scripts\agnes_image.py edit `
  --prompt "Combine these two characters into one dynamic duel scene" `
  --image "C:\Users\YourName\Desktop\char-a.png" `
  --image "C:\Users\YourName\Desktop\char-b.png" `
  --preserve "both character identities and overall framing"
```

### URL 参考图重生成

适合参考图已经在公网：

macOS:

```bash
python3 scripts/agnes_image.py edit \
  --prompt "Turn this into a magazine-style portrait with soft natural light" \
  --image https://example.com/reference.png \
  --preserve "subject identity and composition"
```

Windows PowerShell:

```powershell
py scripts\agnes_image.py edit `
  --prompt "Turn this into a magazine-style portrait with soft natural light" `
  --image https://example.com/reference.png `
  --preserve "subject identity and composition"
```

### 生成并自动保存到本地

适合需要直接落盘，不只看返回 URL：

macOS:

```bash
python3 scripts/agnes_image.py generate \
  --prompt "A premium jewelry ad image on dark stone, cinematic lighting" \
  --download \
  --output-dir /Users/zeng88/Desktop/agnes-output
```

Windows PowerShell:

```powershell
py scripts\agnes_image.py generate `
  --prompt "A premium jewelry ad image on dark stone, cinematic lighting" `
  --download `
  --output-dir "C:\Users\YourName\Desktop\agnes-output"
```

### 图生图并自动保存到本地

适合按参考图出图后直接保存：

macOS:

```bash
python3 scripts/agnes_image.py edit \
  --prompt "Turn this into a fantasy key visual" \
  --image /Users/zeng88/Desktop/ref.png \
  --preserve "main subject and composition" \
  --download \
  --output-dir /Users/zeng88/Desktop/agnes-output
```

Windows PowerShell:

```powershell
py scripts\agnes_image.py edit `
  --prompt "Turn this into a fantasy key visual" `
  --image "C:\Users\YourName\Desktop\ref.png" `
  --preserve "main subject and composition" `
  --download `
  --output-dir "C:\Users\YourName\Desktop\agnes-output"
```

### 中文提示词快速出图

适合不想自己翻英文提示词：

macOS:

```bash
python3 scripts/agnes_image.py generate \
  --prompt "一个奢华珠宝广告图，深色石材背景，电影感灯光"
```

Windows PowerShell:

```powershell
py scripts\agnes_image.py generate `
  --prompt "一个奢华珠宝广告图，深色石材背景，电影感灯光"
```

## 5. 操作示例

### 5.1 文生图

```bash
python3 scripts/agnes_image.py generate \
  --prompt "A cinematic portrait of a woman standing in neon rain, high detail, dramatic lighting" \
  --size 1024x768
```

### 5.2 中文提示词文生图

脚本会自动先翻译提示词，再调用图片模型：

macOS:

```bash
python3 scripts/agnes_image.py generate \
  --prompt "一个站在霓虹雨夜中的女性电影感人像，细节丰富，强烈光影" \
  --size 1024x768
```

Windows PowerShell:

```powershell
py scripts\agnes_image.py generate `
  --prompt "一个站在霓虹雨夜中的女性电影感人像，细节丰富，强烈光影" `
  --size 1024x768
```

### 5.3 图生图：使用本地参考图

macOS:

```bash
python3 scripts/agnes_image.py edit \
  --prompt "Turn this into a cinematic rainy-night portrait with neon reflections" \
  --image /Users/zeng88/Desktop/ref.png \
  --preserve "face identity, hairstyle, outfit silhouette, and composition" \
  --size 1024x768
```

Windows PowerShell:

```powershell
py scripts\agnes_image.py edit `
  --prompt "Turn this into a cinematic rainy-night portrait with neon reflections" `
  --image "C:\Users\YourName\Desktop\ref.png" `
  --preserve "face identity, hairstyle, outfit silhouette, and composition" `
  --size 1024x768
```

### 5.4 图生图：使用公开 URL 参考图

macOS:

```bash
python3 scripts/agnes_image.py edit \
  --prompt "Transform this into a fashion editorial photo with soft window light" \
  --image https://example.com/reference.png \
  --preserve "subject identity and camera angle" \
  --size 1024x768
```

Windows PowerShell:

```powershell
py scripts\agnes_image.py edit `
  --prompt "Transform this into a fashion editorial photo with soft window light" `
  --image https://example.com/reference.png `
  --preserve "subject identity and camera angle" `
  --size 1024x768
```

### 5.5 多参考图图生图

重复传 `--image` 即可：

macOS:

```bash
python3 scripts/agnes_image.py edit \
  --prompt "Combine these references into one cinematic duel scene" \
  --image /Users/zeng88/Desktop/char-a.png \
  --image /Users/zeng88/Desktop/char-b.png \
  --preserve "both character identities and overall framing" \
  --size 1024x768
```

Windows PowerShell:

```powershell
py scripts\agnes_image.py edit `
  --prompt "Combine these references into one cinematic duel scene" `
  --image "C:\Users\YourName\Desktop\char-a.png" `
  --image "C:\Users\YourName\Desktop\char-b.png" `
  --preserve "both character identities and overall framing" `
  --size 1024x768
```

### 5.6 下载生成结果到本地

macOS:

```bash
python3 scripts/agnes_image.py generate \
  --prompt "A luxury perfume bottle on reflective stone, premium advertising style" \
  --size 1024x1024 \
  --download \
  --output-dir /Users/zeng88/Desktop/agnes-output
```

Windows PowerShell:

```powershell
py scripts\agnes_image.py generate `
  --prompt "A luxury perfume bottle on reflective stone, premium advertising style" `
  --size 1024x1024 `
  --download `
  --output-dir "C:\Users\YourName\Desktop\agnes-output"
```

### 5.7 图生图并自动下载到本地

macOS:

```bash
python3 scripts/agnes_image.py edit \
  --prompt "Turn this into a fantasy poster with golden backlight" \
  --image /Users/zeng88/Desktop/poster-ref.jpg \
  --preserve "character pose and composition" \
  --download \
  --output-dir /Users/zeng88/Desktop/agnes-output
```

Windows PowerShell:

```powershell
py scripts\agnes_image.py edit `
  --prompt "Turn this into a fantasy poster with golden backlight" `
  --image "C:\Users\YourName\Desktop\poster-ref.jpg" `
  --preserve "character pose and composition" `
  --download `
  --output-dir "C:\Users\YourName\Desktop\agnes-output"
```

### 5.8 使用固定 seed 提高复现性

macOS:

```bash
python3 scripts/agnes_image.py edit \
  --prompt "Turn this into a cinematic portrait with cool blue tones" \
  --image /Users/zeng88/Desktop/ref.png \
  --preserve "face identity and framing" \
  --seed 42
```

Windows PowerShell:

```powershell
py scripts\agnes_image.py edit `
  --prompt "Turn this into a cinematic portrait with cool blue tones" `
  --image "C:\Users\YourName\Desktop\ref.png" `
  --preserve "face identity and framing" `
  --seed 42
```

### 5.9 返回原始 Provider 响应

macOS:

```bash
python3 scripts/agnes_image.py generate \
  --prompt "A futuristic city skyline at sunrise" \
  --raw
```

Windows PowerShell:

```powershell
py scripts\agnes_image.py generate `
  --prompt "A futuristic city skyline at sunrise" `
  --raw
```

### 5.10 返回 Base64 结果

macOS:

```bash
python3 scripts/agnes_image.py generate \
  --prompt "A glass sculpture floating in a white gallery, studio lighting" \
  --response-format b64_json
```

Windows PowerShell:

```powershell
py scripts\agnes_image.py generate `
  --prompt "A glass sculpture floating in a white gallery, studio lighting" `
  --response-format b64_json
```

## 5.11 推荐提示词模板库

下面这些模板可以直接复制后替换主体内容使用。

### 人像电影感

```text
A cinematic portrait of [subject], standing in [scene], dramatic lighting, rich contrast, realistic skin detail, shallow depth of field, premium editorial photography
```

### 时尚杂志感

```text
A high-fashion editorial portrait of [subject], styled in [outfit/style], photographed in [scene], soft controlled lighting, luxury magazine aesthetic, sharp focus, premium retouching
```

### 雨夜霓虹风

```text
[subject] in a rain-soaked neon night street, cinematic reflections, moody atmosphere, blue and magenta lighting, ultra-detailed, dramatic composition
```

### 棚拍高级人像

```text
A studio beauty portrait of [subject], clean background, professional softbox lighting, crisp facial detail, elegant styling, premium commercial photography
```

### 动漫风重绘

```text
Redraw this as high-quality anime artwork, expressive linework, polished shading, vibrant colors, dynamic composition, preserve the character identity and pose
```

### 油画风重绘

```text
Transform this into a classical oil painting, rich brush texture, warm tones, painterly lighting, museum-quality composition, preserve the subject and overall framing
```

### 商品广告图

```text
A premium product advertising image of [product], placed on [surface/material], luxury lighting, sharp reflections, elegant shadows, high-end commercial photography
```

### 珠宝广告图

```text
A luxury jewelry advertising image featuring [jewelry item], dark stone background, cinematic highlights, premium reflections, elegant composition, ultra-detailed commercial style
```

### 香水广告图

```text
A premium perfume bottle hero shot, reflective stone surface, soft atmospheric haze, cinematic rim lighting, luxury advertising style, crisp glass reflections
```

### 护肤品广告图

```text
A clean luxury skincare product shot, placed on smooth stone, soft daylight, refined shadows, minimal premium aesthetic, beauty campaign style
```

### 海报主视觉

```text
An epic poster key visual featuring [subject], [environment], dramatic backlight, strong focal composition, cinematic atmosphere, ultra-detailed, premium poster design
```

### 奇幻海报

```text
A fantasy poster of [subject], golden backlight, magical particles, epic scale, dramatic sky, cinematic composition, high detail, heroic atmosphere
```

### 科幻海报

```text
A sci-fi key visual featuring [subject], futuristic city background, neon atmosphere, cinematic perspective, high-detail concept art, dramatic lighting
```

### 电商主图

```text
A clean e-commerce hero image of [product], bright controlled lighting, minimal background, premium detail, sharp focus, commercial product photography
```

### 双角色融合

```text
Combine these two characters into one cohesive cinematic scene, preserve both character identities, balanced composition, dynamic interaction, high detail, dramatic lighting
```

### 多参考图融合

```text
Merge the visual information from these reference images into one polished final image, preserve the main identities and overall composition, cinematic quality, consistent lighting
```

### 保脸重生成

```text
Restyle this image into [target style], preserve face identity, hairstyle, facial structure, and overall expression, improve lighting and atmosphere
```

### 保构图重生成

```text
Transform this into [target style], preserve the original camera angle, framing, pose, and composition, enhance detail and mood
```

### 社交媒体封面图

```text
A premium social media cover image featuring [subject], bold focal composition, clean hierarchy, stylish lighting, modern visual identity, high engagement aesthetic
```

### 品牌活动 KV

```text
A premium campaign key visual for [brand/theme], bold composition, polished lighting, strong atmosphere, advertising-grade quality, luxury brand aesthetic
```

### 中文提示词模板

```text
一个[主体]，位于[场景]中，[风格]，[光线]，[构图]，细节丰富，高级质感，商业级画面效果
```

### 图生图推荐保留词模板

可与 `--preserve` 一起使用：

```text
face identity, hairstyle, facial structure, outfit silhouette, body pose, hand pose, camera angle, framing, composition, main subject layout
```

## 6. 主要参数

### 通用参数

- `--prompt`：生成或编辑提示词
- `--size`：输出尺寸，例如 `1024x768`
- `--response-format`：`url` 或 `b64_json`
- `--no-translate`：跳过中文自动翻译
- `--raw`：输出原始返回 JSON

### 图生图参数

- `--image`：参考图，可重复传多个
- `--preserve`：描述哪些内容必须尽量保留
- `--seed`：非负整数，帮助结果更稳定

### 下载参数

- `--download`：下载结果到本地
- `--output-dir`：下载目录
  macOS 默认示例：`~/Desktop/agnes-output`
  Windows 示例：`C:\Users\YourName\Desktop\agnes-output`
- 下载文件名示例：`agnes-20260607-154210-001.png`

## 7. 推荐提示词写法

建议结构：

```text
[主体] + [场景] + [风格] + [光线] + [构图] + [质量要求]
```

图生图时建议同时写清楚：

- 要改什么
- 要保留什么

推荐：

```text
Turn this into a cinematic rainy-night portrait with neon reflections.
Preserve face identity, hairstyle, outfit silhouette, and composition.
```

## 8. 输出说明

默认输出为结构化 JSON，通常包含：

- `type`
- `prompt_used`
- `urls`
- `image_inputs`
- `seed`
- `preserve`
- `raw`
- `local_paths`（当使用 `--download` 时）

使用 `--download` 时，每次执行都会保存成新的唯一文件名，不会覆盖之前已经下载过的图片。

## 9. 常见用法速查

### 只生成图片

macOS:

```bash
python3 scripts/agnes_image.py generate --prompt "your prompt"
```

Windows PowerShell:

```powershell
py scripts\agnes_image.py generate --prompt "your prompt"
```

### 根据参考图重生成

macOS:

```bash
python3 scripts/agnes_image.py edit --prompt "your prompt" --image /path/to/ref.png
```

Windows PowerShell:

```powershell
py scripts\agnes_image.py edit --prompt "your prompt" --image "C:\path\to\ref.png"
```

### 根据参考图重生成并保留主体

macOS:

```bash
python3 scripts/agnes_image.py edit \
  --prompt "your prompt" \
  --image /path/to/ref.png \
  --preserve "face identity, pose, and composition"
```

Windows PowerShell:

```powershell
py scripts\agnes_image.py edit `
  --prompt "your prompt" `
  --image "C:\path\to\ref.png" `
  --preserve "face identity, pose, and composition"
```

### 生成后自动下载

macOS:

```bash
python3 scripts/agnes_image.py generate \
  --prompt "your prompt" \
  --download \
  --output-dir ~/Desktop/agnes-output
```

Windows PowerShell 对应写法：

```powershell
py scripts\agnes_image.py generate `
  --prompt "your prompt" `
  --download `
  --output-dir "C:\Users\YourName\Desktop\agnes-output"
```

## 10. 限制说明

- 这是“参考图引导生成”，不是像素级锁定编辑。
- 公开文档里 Agnes 主要展示的是 URL 参考图输入。
- 当前脚本对本地文件的支持方式，是先转成 `data:` URL 再请求接口。
- 当前脚本下载图片时，会按批次时间戳生成新的文件名，避免重复执行时覆盖旧图。
- 如果你的 Agnes 账户或当前部署环境不接受 `data:` URL，接口会直接报错。
- 是否严格保留人物脸、构图、姿态，仍然依赖模型能力和提示词质量，`--preserve` 只能增强约束，不能绝对保证。

## 11. 常见错误

### API Key 未设置

报错示例：

```text
Missing API key. Set AGNES_API_KEY, AGNES_API_TOKEN, or APIHUB_AGNES_API_KEY.
```

处理方法：

```bash
export AGNES_API_KEY="sk-your-key-here"
```

### 本地图片不存在

报错示例：

```text
Image path does not exist: /path/to/file.png
```

### 图片格式不支持

报错示例：

```text
Unsupported image file type
```

### seed 非法

报错示例：

```text
Invalid seed: expected a non-negative integer.
```

## 12. 相关文件

- [SKILL.md](/Users/zeng88/Desktop/agnes-image-skill/SKILL.md)
- [references/api.md](/Users/zeng88/Desktop/agnes-image-skill/references/api.md)
- [scripts/agnes_image.py](/Users/zeng88/Desktop/agnes-image-skill/scripts/agnes_image.py)
