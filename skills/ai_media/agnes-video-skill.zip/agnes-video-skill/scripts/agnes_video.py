#!/usr/bin/env python3
"""Minimal CLI for Agnes AI video generation API (agnes-video-v2.0).

Subcommands:
  generate  Submit a video task, poll until done, optionally download.
  status    Query a single task by ID.
  recover   Scan the task journal and download any completed tasks.
"""

from __future__ import annotations

import argparse
import base64
import json
import mimetypes
import os
import re
import ssl
import sys
import time
from datetime import datetime
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any

try:
    import certifi
    _SSL_CONTEXT = ssl.create_default_context(cafile=certifi.where())
except ImportError:
    _SSL_CONTEXT = ssl._create_unverified_context()


BASE_URL = "https://apihub.agnes-ai.com"
VIDEO_MODEL = "agnes-video-v2.0"
TEXT_MODEL = "agnes-2.0-flash"
URL_RE = re.compile(r"^https?://", re.IGNORECASE)
DATA_URL_RE = re.compile(r"^data:", re.IGNORECASE)
SUPPORTED_IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp"}
DEFAULT_JOURNAL = "~/Desktop/agnes-output/agnes-video-journal.json"

POLL_RUNNING = {"pending", "queued", "running", "processing", "in_progress"}
POLL_COMPLETED = {"completed", "succeeded", "success"}
POLL_FAILED = {"failed", "error", "cancelled", "canceled"}


# ---------------------------------------------------------------------------
# Auth & HTTP
# ---------------------------------------------------------------------------

def get_api_key() -> str:
    for name in ("AGNES_API_KEY", "AGNES_API_TOKEN", "APIHUB_AGNES_API_KEY"):
        value = os.environ.get(name)
        if value:
            return value
    raise SystemExit(
        "Missing API key. Set AGNES_API_KEY, AGNES_API_TOKEN, or APIHUB_AGNES_API_KEY.\n"
        "Get your key from https://agnes-ai.com"
    )


def request_json(path: str, payload: dict[str, Any]) -> dict[str, Any]:
    body = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        BASE_URL + path,
        data=body,
        method="POST",
        headers={
            "Authorization": f"Bearer {get_api_key()}",
            "Content-Type": "application/json",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=120, context=_SSL_CONTEXT) as resp:
            text = resp.read().decode("utf-8")
            return json.loads(text) if text else {}
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise SystemExit(f"HTTP {exc.code} from {path}: {detail}") from exc
    except urllib.error.URLError as exc:
        raise SystemExit(f"Request failed for {path}: {exc}") from exc


def get_json(path: str) -> dict[str, Any]:
    req = urllib.request.Request(
        BASE_URL + path,
        headers={"Authorization": f"Bearer {get_api_key()}"},
    )
    try:
        with urllib.request.urlopen(req, timeout=30, context=_SSL_CONTEXT) as resp:
            text = resp.read().decode("utf-8")
            return json.loads(text) if text else {}
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise SystemExit(f"HTTP {exc.code} from {path}: {detail}") from exc
    except urllib.error.URLError as exc:
        raise SystemExit(f"Request failed for {path}: {exc}") from exc


def print_json(data: Any) -> None:
    print(json.dumps(data, ensure_ascii=False, indent=2))


# ---------------------------------------------------------------------------
# Prompt translation
# ---------------------------------------------------------------------------

def needs_english_translation(prompt: str) -> bool:
    return any(ord(ch) > 127 for ch in prompt)


def translate_prompt(prompt: str) -> str:
    payload = {
        "model": TEXT_MODEL,
        "messages": [
            {
                "role": "system",
                "content": (
                    "Translate the user's video generation prompt into fluent English. "
                    "Preserve all concrete visual details, style words, camera instructions, "
                    "motion descriptions, lighting, composition constraints, and negative instructions. "
                    "Return only the English prompt, nothing else."
                ),
            },
            {"role": "user", "content": prompt},
        ],
        "temperature": 0,
        "max_tokens": 800,
    }
    data = request_json("/v1/chat/completions", payload)
    try:
        translated = data["choices"][0]["message"]["content"].strip()
    except (KeyError, IndexError, TypeError):
        raise SystemExit("Prompt translation failed.")
    if not translated:
        raise SystemExit("Prompt translation returned empty result.")
    return translated


# ---------------------------------------------------------------------------
# Image input handling
# ---------------------------------------------------------------------------

def image_source_kind(value: str) -> str:
    if URL_RE.match(value):
        return "url"
    if DATA_URL_RE.match(value):
        return "data_url"
    return "path"


def local_image_to_data_url(value: str) -> str:
    path = Path(value).expanduser().resolve()
    if not path.exists():
        raise SystemExit(f"Image path does not exist: {value}")
    if not path.is_file():
        raise SystemExit(f"Image path is not a file: {value}")
    if path.suffix.lower() not in SUPPORTED_IMAGE_EXTENSIONS:
        raise SystemExit(
            f"Unsupported image file type: {path.suffix or '(none)'}; "
            "expected png/jpg/jpeg/webp/gif/bmp."
        )
    mime_type, _ = mimetypes.guess_type(path.name)
    if not mime_type or not mime_type.startswith("image/"):
        mime_type = "application/octet-stream"
    encoded = base64.b64encode(path.read_bytes()).decode("ascii")
    return f"data:{mime_type};base64,{encoded}"


def normalize_single_image(value: str) -> tuple[str, dict[str, str]]:
    kind = image_source_kind(value)
    if kind == "path":
        data_url = local_image_to_data_url(value)
        return data_url, {"input": value, "source_type": "local_path", "transport": "data_url"}
    return value, {"input": value, "source_type": kind, "transport": "verbatim"}


# ---------------------------------------------------------------------------
# Duration / frames
# ---------------------------------------------------------------------------

def duration_to_frames(duration: float, frame_rate: int) -> int:
    return int(duration * frame_rate) + 1


# ---------------------------------------------------------------------------
# Task journal (JSON file keyed by task_id)
# ---------------------------------------------------------------------------

def _journal_path(journal: str) -> Path:
    return Path(journal).expanduser().resolve()


def load_journal(journal: str) -> dict[str, Any]:
    p = _journal_path(journal)
    if not p.exists():
        return {}
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return {}


def save_journal(journal: str, data: dict[str, Any]) -> None:
    p = _journal_path(journal)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def journal_write_task(journal: str, record: dict[str, Any]) -> None:
    data = load_journal(journal)
    data[record["task_id"]] = record
    save_journal(journal, data)


def journal_update_task(journal: str, task_id: str, updates: dict[str, Any]) -> None:
    data = load_journal(journal)
    if task_id in data:
        data[task_id].update(updates)
        data[task_id]["last_updated"] = _now()
    save_journal(journal, data)


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%dT%H:%M:%S")


# ---------------------------------------------------------------------------
# API response helpers
# ---------------------------------------------------------------------------

def extract_task_id(data: dict[str, Any]) -> str | None:
    for key in ("id", "task_id", "taskId"):
        if isinstance(data.get(key), str) and data[key]:
            return data[key]
    return None


def extract_video_id(data: dict[str, Any]) -> str | None:
    for key in ("video_id", "videoId"):
        if isinstance(data.get(key), str) and data[key]:
            return data[key]
    return None


def extract_video_url(data: dict[str, Any]) -> str | None:
    # Standard fields first
    for key in ("video_url", "videoUrl", "url", "output"):
        v = data.get(key)
        if isinstance(v, str) and v:
            return v
    # remixed_from_video_id is used by this API to carry the download URL
    v = data.get("remixed_from_video_id")
    if isinstance(v, str) and v.startswith("http"):
        return v
    if isinstance(data.get("data"), dict):
        return extract_video_url(data["data"])
    return None


def get_task_status(data: dict[str, Any]) -> str:
    for key in ("status", "state"):
        v = data.get(key)
        if isinstance(v, str) and v:
            return v.lower()
    return "unknown"


# ---------------------------------------------------------------------------
# ID helpers
# ---------------------------------------------------------------------------

def _preferred_query_id(rec: dict[str, Any]) -> str:
    """Return the ID to use for GET /v1/videos/{id}.

    Empirically only task_id is accepted by the polling endpoint.
    video_id in API responses is a litellm-internal base64 blob and is
    NOT usable as a direct GET path parameter — it is stored in the journal
    purely as a lookup key so users can filter by video_id in recover/status.
    """
    return rec.get("task_id") or ""


def _find_record_by_id(data: dict[str, Any], id_value: str) -> tuple[str, dict[str, Any]] | None:
    """Look up a journal record by task_id or video_id. Returns (task_id, record) or None."""
    # Direct key lookup (task_id)
    if id_value in data:
        return id_value, data[id_value]
    # Scan for matching video_id
    for task_id, rec in data.items():
        if rec.get("video_id") == id_value:
            return task_id, rec
    return None


# ---------------------------------------------------------------------------
# Polling
# ---------------------------------------------------------------------------

def poll_task(
    task_id: str,
    query_id: str,
    journal: str,
    timeout: int = 900,
    interval: int = 5,
) -> dict[str, Any]:
    """Poll until completed/failed. Updates journal on each tick. Returns final response.

    task_id  — journal key (always task_id)
    query_id — ID used for GET /v1/videos/{id} (video_id preferred, fallback task_id)
    """
    deadline = time.monotonic() + timeout
    print(f"  Task ID  : {task_id}", file=sys.stderr)
    print(f"  Query ID : {query_id}", file=sys.stderr)
    print(f"  Waiting for video generation (timeout={timeout}s, poll every {interval}s)...", file=sys.stderr)

    while time.monotonic() < deadline:
        data = get_json(f"/v1/videos/{query_id}")
        status = get_task_status(data)
        progress = data.get("progress", "?")
        elapsed = int(timeout - (deadline - time.monotonic()))
        print(f"  [{elapsed:>4}s] status={status}  progress={progress}%", file=sys.stderr)

        journal_update_task(journal, task_id, {"status": status, "progress": progress})

        if status in POLL_COMPLETED:
            return data
        if status in POLL_FAILED:
            err = data.get("error") or data.get("message") or status
            journal_update_task(journal, task_id, {"status": "failed", "error": str(err)})
            raise SystemExit(f"Video generation failed: {err}")

        time.sleep(interval)

    # Timed out — record status so recover can retry later
    journal_update_task(journal, task_id, {"status": "timeout"})
    raise SystemExit(
        f"\nTimed out after {timeout}s. Task {task_id} may still be running.\n"
        f"Run `python scripts/agnes_video.py recover` later to check and download."
    )


# ---------------------------------------------------------------------------
# Download
# ---------------------------------------------------------------------------

def allocate_output_path(output_dir: Path, batch_id: str, index: int, ext: str) -> Path:
    filename = output_dir / f"agnes-{batch_id}-{index:03d}.{ext}"
    if not filename.exists():
        return filename
    suffix = 1
    while True:
        filename = output_dir / f"agnes-{batch_id}-{index:03d}-{suffix:02d}.{ext}"
        if not filename.exists():
            return filename
        suffix += 1


def download_video(url: str, output_dir: str) -> str:
    out = Path(output_dir).expanduser().resolve()
    out.mkdir(parents=True, exist_ok=True)
    batch_id = datetime.now().strftime("%Y%m%d-%H%M%S")
    filename = allocate_output_path(out, batch_id, 1, "mp4")
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    try:
        with urllib.request.urlopen(req, timeout=300, context=_SSL_CONTEXT) as resp:
            filename.write_bytes(resp.read())
        print(f"  Saved: {filename}", file=sys.stderr)
        return str(filename)
    except Exception as exc:
        print(f"  Warning: failed to download {url}: {exc}", file=sys.stderr)
        return ""


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------

def cmd_generate(args: argparse.Namespace) -> None:
    if args.duration <= 0:
        raise SystemExit("--duration must be a positive number.")
    if args.seed is not None and args.seed < 0:
        raise SystemExit("--seed must be a non-negative integer.")

    prompt = args.prompt
    translated = None
    image_normalized = None
    image_meta = None

    if args.image:
        image_normalized, image_meta = normalize_single_image(args.image)

    if not args.no_translate and needs_english_translation(prompt):
        print("Translating prompt to English...", file=sys.stderr)
        translated = translate_prompt(prompt)
        prompt = translated
        print(f"  Original  : {args.prompt}", file=sys.stderr)
        print(f"  Translated: {prompt}", file=sys.stderr)

    num_frames = duration_to_frames(args.duration, args.frame_rate)

    payload: dict[str, Any] = {
        "model": VIDEO_MODEL,
        "prompt": prompt,
        "width": args.width,
        "height": args.height,
        "num_frames": num_frames,
        "frame_rate": args.frame_rate,
    }
    if args.seed is not None:
        payload["seed"] = args.seed
    if image_normalized:
        payload["image"] = image_normalized

    print(f"  Submitting task (duration={args.duration}s → {num_frames} frames)...", file=sys.stderr)
    create_resp = request_json("/v1/video/generations", payload)

    task_id = extract_task_id(create_resp)
    if not task_id:
        raise SystemExit(f"No task ID in response: {json.dumps(create_resp)}")

    # Write initial journal record immediately after task creation
    journal_record: dict[str, Any] = {
        "task_id": task_id,
        "video_id": extract_video_id(create_resp),
        "created_at": _now(),
        "prompt": prompt,
        "original_prompt": args.prompt if translated else None,
        "duration": args.duration,
        "width": args.width,
        "height": args.height,
        "frame_rate": args.frame_rate,
        "seed": args.seed,
        "image_input": image_meta,
        "status": get_task_status(create_resp) or "queued",
        "progress": 0,
        "video_url": None,
        "local_path": None,
        "completed_at": None,
        "error": None,
        "output_dir": args.output_dir,
        "last_updated": _now(),
    }
    journal_write_task(args.journal, journal_record)
    print(f"  Video ID  : {journal_record['video_id'] or '(not returned)'}", file=sys.stderr)
    print(f"  Journal   : {Path(args.journal).expanduser()}", file=sys.stderr)

    # Quick-wait loop: poll until completed, failed, running, or 30s elapsed.
    # If completed quickly → download and finish normally.
    # If status turns "running" or 30s pass → print task snapshot and exit
    # with instructions so the terminal isn't blocked for long generations.
    QUICK_WAIT = 30
    deadline = time.monotonic() + QUICK_WAIT
    last_data: dict[str, Any] = {}

    print(f"  Watching for up to {QUICK_WAIT}s (exits early once running)...", file=sys.stderr)

    while True:
        last_data = get_json(f"/v1/videos/{task_id}")
        status = get_task_status(last_data)
        progress = last_data.get("progress", "?")
        elapsed = int(QUICK_WAIT - max(0.0, deadline - time.monotonic()))
        print(f"  [{elapsed:>3}s] status={status}  progress={progress}%", file=sys.stderr)

        journal_update_task(args.journal, task_id, {"status": status, "progress": progress})

        if status in POLL_COMPLETED:
            video_url = extract_video_url(last_data)
            journal_update_task(args.journal, task_id, {
                "status": "completed",
                "video_url": video_url,
                "completed_at": _now(),
                "progress": 100,
            })
            result: dict[str, Any] = {
                "type": "image-to-video" if image_normalized else "text-to-video",
                "prompt_used": prompt,
                "task_id": task_id,
                "video_id": journal_record["video_id"],
                "status": "completed",
                "video_url": video_url,
                "duration_seconds": args.duration,
                "size": f"{args.width}x{args.height}",
            }
            if translated:
                result["original_prompt"] = args.prompt
                result["translated_prompt"] = translated
            if image_meta:
                result["image_input"] = image_meta
            if args.seed is not None:
                result["seed"] = args.seed
            if args.download and video_url:
                local_path = download_video(video_url, args.output_dir)
                if local_path:
                    result["local_path"] = local_path
                    journal_update_task(args.journal, task_id, {
                        "status": "downloaded",
                        "local_path": local_path,
                    })
                    print(f"\nDownloaded: {local_path}", file=sys.stderr)
            print_json(last_data if args.raw else result)
            return

        if status in POLL_FAILED:
            err = last_data.get("error") or last_data.get("message") or status
            journal_update_task(args.journal, task_id, {"status": "failed", "error": str(err)})
            raise SystemExit(f"Video generation failed: {err}")

        timed_out = time.monotonic() >= deadline
        if status == "running" or timed_out:
            reason = "status=running" if status == "running" else f"{QUICK_WAIT}s elapsed"
            print(f"\n  [{reason}] Task is processing in the background.", file=sys.stderr)
            break

        time.sleep(5)

    # Print raw API snapshot then recovery instructions
    print_json(last_data)
    print(file=sys.stderr)
    print("=" * 55, file=sys.stderr)
    print("  Task submitted. Generation is running in the background.", file=sys.stderr)
    print(f"  task_id : {task_id}", file=sys.stderr)
    print(file=sys.stderr)
    print("  Check progress:", file=sys.stderr)
    print(f"    python3 scripts/agnes_video.py status --task-id {task_id}", file=sys.stderr)
    print(file=sys.stderr)
    print("  When completed, download with:", file=sys.stderr)
    print(f"    python3 scripts/agnes_video.py recover --task-id {task_id}", file=sys.stderr)
    print("=" * 55, file=sys.stderr)


def cmd_status(args: argparse.Namespace) -> None:
    if args.task_id:
        query_id = args.task_id
    else:
        # video_id cannot be used directly as a GET path parameter —
        # look it up in the journal to resolve the task_id first.
        journal_data = load_journal(args.journal)
        found = _find_record_by_id(journal_data, args.video_id)
        if not found:
            raise SystemExit(
                f"video_id '{args.video_id}' not found in journal "
                f"({Path(args.journal).expanduser()}).\n"
                "Use --task-id to query directly without the journal."
            )
        task_id_key, rec = found
        query_id = rec["task_id"]
        print(f"  Resolved video_id → task_id: {query_id}", file=sys.stderr)
    data = get_json(f"/v1/videos/{query_id}")
    print_json(data)


def cmd_recover(args: argparse.Namespace) -> None:
    """Check unfinished tasks in the journal and download any that have completed."""
    journal_path = Path(args.journal).expanduser()
    data = load_journal(args.journal)

    if not data:
        print(f"Journal is empty or not found: {journal_path}", file=sys.stderr)
        return

    # If a specific ID was given, resolve it to a task_id-keyed subset
    filter_id = args.video_id or args.task_id
    if filter_id:
        found = _find_record_by_id(data, filter_id)
        if not found:
            raise SystemExit(f"ID '{filter_id}' not found in journal (checked task_id and video_id).")
        task_id_key, rec = found
        candidates = {task_id_key: rec}
    else:
        skip_statuses = {"downloaded", "failed"}
        candidates = {
            tid: rec for tid, rec in data.items()
            if rec.get("status") not in skip_statuses
        }

    if not candidates:
        print("No pending tasks to recover.", file=sys.stderr)
        return

    print(f"Checking {len(candidates)} task(s)...\n", file=sys.stderr)

    summary: dict[str, list] = {"downloaded": [], "still_running": [], "failed": [], "errors": []}

    for task_id, rec in candidates.items():
        video_id = rec.get("video_id")
        query_id = _preferred_query_id(rec)
        id_label = f"task_id={task_id}" + (f"  video_id={video_id}" if video_id else "")
        print(f"  [{id_label}]", file=sys.stderr)
        print(f"    created={rec.get('created_at', '?')}  last_status={rec.get('status', '?')}", file=sys.stderr)
        print(f"    Querying via: {query_id} (task_id)", file=sys.stderr)

        try:
            remote = get_json(f"/v1/videos/{query_id}")
        except SystemExit as exc:
            print(f"    Error: {exc}", file=sys.stderr)
            summary["errors"].append(task_id)
            print(file=sys.stderr)
            continue

        status = get_task_status(remote)
        progress = remote.get("progress", "?")
        print(f"    Remote: status={status}  progress={progress}%", file=sys.stderr)

        journal_update_task(args.journal, task_id, {"status": status, "progress": progress})

        if status in POLL_COMPLETED:
            video_url = extract_video_url(remote)
            journal_update_task(args.journal, task_id, {
                "status": "completed",
                "video_url": video_url,
                "completed_at": _now(),
            })
            output_dir = rec.get("output_dir") or args.output_dir
            if video_url:
                local_path = download_video(video_url, output_dir)
                if local_path:
                    journal_update_task(args.journal, task_id, {
                        "status": "downloaded",
                        "local_path": local_path,
                    })
                    summary["downloaded"].append({"task_id": task_id, "video_id": video_id, "local_path": local_path})
                    print(f"    Downloaded: {local_path}", file=sys.stderr)
            else:
                print(f"    Completed but no video URL in response.", file=sys.stderr)

        elif status in POLL_FAILED:
            err = remote.get("error") or remote.get("message") or status
            journal_update_task(args.journal, task_id, {"status": "failed", "error": str(err)})
            summary["failed"].append({"task_id": task_id, "video_id": video_id, "error": str(err)})
            print(f"    Failed: {err}", file=sys.stderr)

        else:
            summary["still_running"].append({"task_id": task_id, "video_id": video_id, "status": status, "progress": progress})
            print(f"    Still running, try again later.", file=sys.stderr)

        print(file=sys.stderr)

    # Summary
    print("=" * 50, file=sys.stderr)
    print(f"  Downloaded    : {len(summary['downloaded'])}", file=sys.stderr)
    print(f"  Still running : {len(summary['still_running'])}", file=sys.stderr)
    print(f"  Failed        : {len(summary['failed'])}", file=sys.stderr)
    print(f"  Errors        : {len(summary['errors'])}", file=sys.stderr)
    print(f"\nJournal updated: {journal_path}", file=sys.stderr)

    print_json({
        "downloaded": summary["downloaded"],
        "still_running": summary["still_running"],
        "failed": summary["failed"],
        "errors": summary["errors"],
    })


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Call Agnes AI video generation API (agnes-video-v2.0)."
    )
    sub = parser.add_subparsers(dest="command")

    # Shared parent: download + journal
    base_parent = argparse.ArgumentParser(add_help=False)
    base_parent.add_argument(
        "--journal",
        default=DEFAULT_JOURNAL,
        help=f"Path to task journal JSON file. Default: {DEFAULT_JOURNAL}",
    )
    base_parent.add_argument(
        "--output-dir",
        default="~/Desktop/agnes-output",
        help="Directory to save downloaded video. Default: ~/Desktop/agnes-output",
    )

    download_parent = argparse.ArgumentParser(add_help=False)
    download_parent.add_argument(
        "--download",
        action="store_true",
        help="Auto-download video after generation completes.",
    )

    # generate
    gen = sub.add_parser(
        "generate",
        parents=[base_parent, download_parent],
        help="Submit a video generation task, poll, and optionally download.",
    )
    gen.add_argument("--prompt", required=True, help="Video description.")
    gen.add_argument(
        "--image",
        help="Input image for image-to-video. Local file path or public HTTPS URL.",
    )
    gen.add_argument("--duration", type=float, default=5.0, help="Duration in seconds. Default: 5.0")
    gen.add_argument("--width", type=int, default=1152, help="Width in pixels. Default: 1152")
    gen.add_argument("--height", type=int, default=768, help="Height in pixels. Default: 768")
    gen.add_argument("--frame-rate", type=int, default=24, help="Frames per second. Default: 24")
    gen.add_argument("--seed", type=int, help="Non-negative random seed.")
    gen.add_argument("--no-translate", action="store_true", help="Skip auto-translation of non-English prompts.")
    gen.add_argument("--timeout", type=int, default=900, help="Max poll wait in seconds. Default: 900")
    gen.add_argument("--raw", action="store_true", help="Print raw provider response.")
    gen.set_defaults(func=cmd_generate)

    # status
    status = sub.add_parser("status", help="Query a task by video_id or task_id.")
    id_group = status.add_mutually_exclusive_group(required=True)
    id_group.add_argument(
        "--video-id",
        default=None,
        help="Video ID. Resolved to task_id via local journal before querying API.",
    )
    id_group.add_argument(
        "--task-id",
        default=None,
        help="Task ID. Queried directly against the API.",
    )
    status.add_argument(
        "--journal",
        default=DEFAULT_JOURNAL,
        help=f"Journal file used to resolve video_id. Default: {DEFAULT_JOURNAL}",
    )
    status.set_defaults(func=cmd_status)

    # recover
    recover = sub.add_parser(
        "recover",
        parents=[base_parent],
        help="Check unfinished tasks in the journal and download completed ones.",
    )
    recover_id = recover.add_mutually_exclusive_group()
    recover_id.add_argument(
        "--video-id",
        default=None,
        help="Only recover the task matching this video_id (recommended).",
    )
    recover_id.add_argument(
        "--task-id",
        default=None,
        help="Only recover the task matching this task_id.",
    )
    recover.set_defaults(func=cmd_recover)

    return parser


def main() -> None:
    if len(sys.argv) == 1:
        build_parser().print_help()
        sys.exit(0)
    args = build_parser().parse_args()
    if hasattr(args, "func"):
        args.func(args)
    else:
        build_parser().print_help()


if __name__ == "__main__":
    main()
