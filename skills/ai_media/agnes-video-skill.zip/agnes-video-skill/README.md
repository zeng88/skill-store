# Agnes Video Skill

调用 [Agnes Video V2.0](https://agnes-ai.com/doc/agnes-video-v20) 生成高质量视频。支持文字生成视频、图片生成视频，内置任务日志系统，即使生成超时也能事后恢复下载。

---

## 目录

- [功能特性](#功能特性)
- [目录结构](#目录结构)
- [环境准备](#环境准备)
- [快速开始](#快速开始)
- [命令详解](#命令详解)
  - [generate — 生成视频](#generate--生成视频)
  - [recover — 恢复下载](#recover--恢复下载)
  - [status — 查询任务](#status--查询任务)
- [参数说明](#参数说明)
- [task_id 与 video_id 说明](#task_id-与-video_id-说明)
- [任务日志系统](#任务日志系统)
- [输出说明](#输出说明)
- [提示词写法](#提示词写法)
- [常见问题](#常见问题)

---

## 功能特性

| 功能 | 说明 |
|------|------|
| 文生视频 | 根据文字描述生成视频 |
| 图生视频 | 以图片为基础生成带动态效果的视频 |
| 本地图片输入 | 传入本地文件路径，自动转换为 data URL 上传 |
| URL 图片输入 | 传入公开 HTTPS 图片链接直接使用 |
| 自定义时长 | `--duration` 指定视频秒数，自动换算帧数 |
| 自动下载 | `--download` 生成后自动保存 `.mp4` 到本地 |
| 中文提示词 | 检测到中文自动翻译为英文后调用 API |
| 任务日志 | 任务创建后立即写入本地 JSON 日志，task_id 和 video_id 永不丢失 |
| 超时恢复 | `recover` 命令扫描日志，补充下载所有已完成但未下载的视频 |
| 双 ID 查询 | `status` / `recover` 均支持 `--task-id` 和 `--video-id` 两种方式定位任务 |

---

## 目录结构

```
agnes-video-skill/
├── README.md                     本文档
├── SKILL.md                      Skill 定义（供 Agent 使用）
├── docs/
│   └── implementation-plan.md   技术实现方案记录
├── scripts/
│   └── agnes_video.py            核心 CLI 脚本
└── references/
    └── api.md                    Agnes Video API 技术参考
```

---

## 环境准备

### 1. 获取 API Key

前往 [https://agnes-ai.com](https://agnes-ai.com) 注册并获取免费 API Key。

### 2. 设置 API Key

**方式一：当前终端会话（临时）**

```bash
export AGNES_API_KEY="sk-your-key-here"
```

**方式二：永久写入配置文件（推荐）**

```bash
# zsh 用户
echo 'export AGNES_API_KEY="sk-your-key-here"' >> ~/.zshrc
source ~/.zshrc

# bash 用户
echo 'export AGNES_API_KEY="sk-your-key-here"' >> ~/.bashrc
source ~/.bashrc
```

支持以下任意一个环境变量名，脚本按顺序读取：

```
AGNES_API_KEY          ← 优先
AGNES_API_TOKEN
APIHUB_AGNES_API_KEY
```

### 3. Python 要求

- Python **3.8** 及以上
- 仅依赖标准库，**无需 pip 安装额外依赖**
- 可选安装 `certifi` 解决 macOS SSL 证书问题：

```bash
pip install certifi
```

---

## 快速开始

```bash
cd ~/Desktop/agnes-video-skill
```

```bash
python3 scripts/agnes_video.py generate \
  --prompt "A glowing city above misty clouds at sunset, cinematic, 4K" \
  --duration 5 --download
```

脚本实时输出进度，完成后自动下载：

```
  Submitting task (duration=5.0s → 121 frames)...
  Task ID  : task_CgaeT9xfPU...
  Video ID : video_bGl0ZWxs...
  Journal  : /Users/you/Desktop/agnes-output/agnes-video-journal.json
  Waiting for video generation (timeout=900s, poll every 5s)...
  [   5s] status=queued    progress=0%
  [  10s] status=running   progress=12%
  [  80s] status=running   progress=78%
  [ 120s] status=completed progress=100%
  Saved: /Users/you/Desktop/agnes-output/agnes-20260610-153045-001.mp4

Downloaded: /Users/you/Desktop/agnes-output/agnes-20260610-153045-001.mp4
```

---

## 命令详解

### generate — 生成视频

提交视频生成任务，实时轮询进度，完成后可自动下载。**每次任务创建后立即写入日志，task_id 和 video_id 不会因超时或中断而丢失。**

#### 文生视频

```bash
python3 scripts/agnes_video.py generate \
  --prompt "A glowing city above misty clouds at sunset, cinematic, 4K" \
  --duration 5 --download
```

#### 文生视频（中文提示词，自动翻译）

```bash
python3 scripts/agnes_video.py generate \
  --prompt "一只熊猫在竹林里缓缓走动，阳光透过竹叶，4K写实风格" \
  --duration 5 --download
```

检测到非 ASCII 字符后自动调用 `agnes-2.0-flash` 翻译为英文，翻译结果打印到 stderr 供核查。

#### 图生视频（本地图片路径）

```bash
python3 scripts/agnes_video.py generate \
  --prompt "让画面中的树木随风轻轻摇曳，加入飘落的花瓣" \
  --image ~/Desktop/photo.jpg \
  --duration 5 --download
```

本地图片自动读取并以 base64 data URL 上传，支持格式：`.png .jpg .jpeg .webp .gif .bmp`。

#### 图生视频（图片 URL）

```bash
python3 scripts/agnes_video.py generate \
  --prompt "Add cinematic rain and neon reflections" \
  --image https://example.com/photo.jpg \
  --duration 5 --download
```

#### 指定视频时长

```bash
# 3 秒短片
python3 scripts/agnes_video.py generate \
  --prompt "Ocean waves rolling onto a beach at golden hour" \
  --duration 3 --download

# 10 秒长片
python3 scripts/agnes_video.py generate \
  --prompt "延时拍摄，云层在雪山顶快速翻涌" \
  --duration 10 --download
```

时长与帧数换算：`num_frames = int(duration × frame_rate) + 1`

| 时长 | 帧率 | 帧数 |
|------|------|------|
| 3 秒 | 24 fps | 73 帧 |
| 5 秒 | 24 fps | 121 帧 |
| 10 秒 | 24 fps | 241 帧 |

#### 自定义分辨率

```bash
# 竖屏 9:16
python3 scripts/agnes_video.py generate \
  --prompt "繁华都市街道，人群涌动，竖屏短视频风格" \
  --width 768 --height 1152 --duration 5 --download

# 正方形 1:1
python3 scripts/agnes_video.py generate \
  --prompt "A spinning galaxy, deep space photography" \
  --width 1024 --height 1024 --duration 5 --download
```

#### 固定随机种子

```bash
python3 scripts/agnes_video.py generate \
  --prompt "Northern lights dancing over a frozen lake" \
  --duration 5 --seed 42 --download
```

#### 调长超时（长视频或繁忙时段）

```bash
python3 scripts/agnes_video.py generate \
  --prompt "An epic battle scene with dragons and lightning" \
  --duration 10 --timeout 1800 --download
```

#### 只提交，不等待（之后用 recover 下载）

```bash
# 超短超时让脚本立即退出，task_id 已写入日志
python3 scripts/agnes_video.py generate \
  --prompt "A futuristic city at night" \
  --duration 5 --timeout 1
```

---

### recover — 恢复下载

扫描任务日志，查询所有**未完成**任务的最新状态，对已完成的自动下载并回写日志。`recover` 无需 `--download` 参数，发现已完成任务后**始终自动下载**。

**典型场景：**
- `generate` 轮询超时后补回下载
- 批量提交多个任务后统一检查结果

#### 检查并下载所有未完成任务

```bash
python3 scripts/agnes_video.py recover
```

输出示例：

```
Checking 2 task(s)...

  [task_id=task_abc123  video_id=video_xyz789]
    created=2026-06-10T15:30:45  last_status=timeout
    Querying via: task_abc123 (task_id)
    Remote: status=completed  progress=100%
    Downloaded: /Users/you/Desktop/agnes-output/agnes-20260610-160012-001.mp4

  [task_id=task_def456  video_id=video_uvw123]
    created=2026-06-10T15:45:00  last_status=running
    Querying via: task_def456 (task_id)
    Remote: status=running  progress=45%
    Still running, try again later.

==================================================
  Downloaded    : 1
  Still running : 1
  Failed        : 0
  Errors        : 0

Journal updated: /Users/you/Desktop/agnes-output/agnes-video-journal.json
```

#### 按 task_id 恢复指定任务

```bash
python3 scripts/agnes_video.py recover --task-id task_abc123
```

#### 按 video_id 恢复指定任务

```bash
python3 scripts/agnes_video.py recover --video-id video_xyz789
```

`--task-id` 和 `--video-id` 互斥，二选一即可。脚本会在日志中匹配对应记录，找到后统一用 task_id 调用 API。

#### 指定日志文件和下载目录

```bash
python3 scripts/agnes_video.py recover \
  --journal ~/Documents/my-video-tasks.json \
  --output-dir ~/Movies/agnes
```

---

### status — 查询任务

实时查询单个任务状态，输出原始 API 响应。支持用 `--task-id` 或 `--video-id` 定位，二选一。

#### 按 task_id 查询

```bash
python3 scripts/agnes_video.py status --task-id task_abc123
```

#### 按 video_id 查询

```bash
python3 scripts/agnes_video.py status --video-id video_xyz789
```

输出示例：

```json
{
  "id": "task_abc123",
  "object": "video",
  "status": "running",
  "progress": 65,
  "created_at": 1781060186,
  "completed_at": null,
  "video_url": null,
  "seconds": "5.0",
  "size": "1152x768",
  "model": "agnes-video-v2.0"
}
```

---

## 参数说明

### `generate` 子命令

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `--prompt` | 字符串 | **必填** | 视频内容描述，支持中文（自动翻译） |
| `--image` | 路径或URL | — | 图生视频的输入图片，本地路径或 HTTPS URL |
| `--duration` | 小数 | `5.0` | 视频时长（秒），自动换算为帧数 |
| `--width` | 整数 | `1152` | 视频宽度（像素） |
| `--height` | 整数 | `768` | 视频高度（像素） |
| `--frame-rate` | 整数 | `24` | 帧率（fps） |
| `--seed` | 整数 | — | 随机种子，非负整数，用于复现结果 |
| `--no-translate` | 标志 | — | 禁用中文自动翻译 |
| `--download` | 标志 | — | 生成完成后自动下载视频 |
| `--output-dir` | 路径 | `~/Desktop/agnes-output` | 视频下载保存目录 |
| `--journal` | 路径 | `~/Desktop/agnes-output/agnes-video-journal.json` | 任务日志文件路径 |
| `--timeout` | 整数 | `900` | 轮询最长等待秒数（超时后可用 recover 恢复） |
| `--raw` | 标志 | — | 输出原始 API 响应 JSON |

### `recover` 子命令

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `--task-id` | 字符串 | — | 只恢复此 task_id 对应任务（与 `--video-id` 二选一） |
| `--video-id` | 字符串 | — | 只恢复此 video_id 对应任务（与 `--task-id` 二选一） |
| `--journal` | 路径 | `~/Desktop/agnes-output/agnes-video-journal.json` | 任务日志文件路径 |
| `--output-dir` | 路径 | `~/Desktop/agnes-output` | 下载目录（优先用日志中记录的原始目录） |

### `status` 子命令

| 参数 | 类型 | 说明 |
|------|------|------|
| `--task-id` | 字符串 | 按 task_id 查询（与 `--video-id` 二选一，**必填其一**） |
| `--video-id` | 字符串 | 按 video_id 查询（与 `--task-id` 二选一，**必填其一**） |

---

## task_id 与 video_id 说明

每次任务创建时 API 会同时返回 `task_id` 和 `video_id`，两者都保存在日志中。

| 字段 | 格式示例 | 用途 |
|------|----------|------|
| `task_id` | `task_lTdYLKXA...` | API 轮询端点实际接受的 ID，格式简洁 |
| `video_id` | `video_bGl0ZWxs...`（base64 编码） | API 返回的视频标识，内含模型和版本元数据 |

**`--video-id` 与 `--task-id` 的工作方式相同**：两者都通过扫描本地日志文件定位记录，找到后脚本内部统一使用 `task_id` 调用 API。因此无论你手头有哪个 ID，都可以直接传入，结果完全一致。

```bash
# 以下两条命令等效（定位的是同一条日志记录）
python3 scripts/agnes_video.py recover --task-id task_lTdYLKXA...
python3 scripts/agnes_video.py recover --video-id video_bGl0ZWxs...
```

---

## 任务日志系统

### 为什么需要日志

Agnes Video V2.0 的视频生成是**异步任务**，通常需要数分钟乃至更长时间。如果轮询超时、终端关闭或网络中断，任务仍在服务器运行，但脚本退出后 ID 就丢失了，无法事后下载。

**任务日志系统的保证：任务创建成功后立即持久化所有 ID 和参数，与轮询是否成功完全无关。**

### 日志文件位置

默认：`~/Desktop/agnes-output/agnes-video-journal.json`

可用 `--journal` 指定自定义路径。

### 日志格式

以 `task_id` 为 key 的 JSON 对象，每条记录包含完整任务信息：

```json
{
  "task_abc123": {
    "task_id": "task_abc123",
    "video_id": "video_bGl0ZWxs...",
    "created_at": "2026-06-10T15:30:45",
    "prompt": "A glowing city above misty clouds at sunset, cinematic, 4K",
    "original_prompt": "日落时分云海上方发光的城市",
    "duration": 5.0,
    "width": 1152,
    "height": 768,
    "frame_rate": 24,
    "seed": null,
    "image_input": null,
    "status": "downloaded",
    "progress": 100,
    "video_url": "https://storage.googleapis.com/...",
    "local_path": "/Users/you/Desktop/agnes-output/agnes-20260610-153045-001.mp4",
    "completed_at": "2026-06-10T15:33:02",
    "error": null,
    "output_dir": "~/Desktop/agnes-output",
    "last_updated": "2026-06-10T15:33:15"
  }
}
```

### 任务状态流转

```
提交任务
    ↓
  queued       ← 刚创建，服务器排队中
    ↓
  running      ← 正在生成（每次轮询更新 progress）
    ↓
  completed    ← 生成完成，video_url 已写入日志
    ↓
  downloaded   ← 视频已下载，local_path 已写入日志

  timeout      ← 轮询等待超时（task 仍在运行），执行 recover 可恢复
  failed       ← 服务器报告生成失败
```

### 日志更新时机

| 时机 | 写入内容 |
|------|----------|
| 任务创建成功后（立即） | 初始记录全量写入，status=queued |
| 每次轮询返回 | 更新 status、progress、last_updated |
| 轮询超时退出 | 更新 status=timeout |
| 生成完成 | 更新 status=completed，写入 video_url、completed_at |
| 视频下载成功 | 更新 status=downloaded，写入 local_path |
| 任务失败 | 更新 status=failed，写入 error 原因 |

### 超时恢复完整流程

```bash
# 步骤一：提交任务（超时没关系，日志已记录）
python3 scripts/agnes_video.py generate \
  --prompt "Epic volcanic eruption at midnight" \
  --duration 10 --download
# → 超时后输出：
#   Timed out after 900s. Task task_xyz may still be running.
#   Run `python scripts/agnes_video.py recover` later to check and download.

# 步骤二：等待几分钟后执行 recover，自动检查状态并下载
python3 scripts/agnes_video.py recover
```

### 查看日志内容

```bash
cat ~/Desktop/agnes-output/agnes-video-journal.json
```

---

## 输出说明

### `generate` 成功输出

```json
{
  "type": "text-to-video",
  "prompt_used": "A glowing city above misty clouds at sunset, cinematic, 4K",
  "task_id": "task_abc123",
  "video_id": "video_bGl0ZWxs...",
  "status": "completed",
  "video_url": "https://storage.googleapis.com/agnes-video/output/xxx.mp4",
  "duration_seconds": 5.0,
  "size": "1152x768",
  "local_path": "/Users/you/Desktop/agnes-output/agnes-20260610-153045-001.mp4"
}
```

若有中文翻译，额外包含：

```json
{
  "original_prompt": "发光的城市，云海之上",
  "translated_prompt": "A glowing city above the sea of clouds..."
}
```

若有图片输入，额外包含：

```json
{
  "image_input": {
    "input": "~/Desktop/photo.jpg",
    "source_type": "local_path",
    "transport": "data_url"
  }
}
```

### `recover` 输出

```json
{
  "downloaded": [
    {
      "task_id": "task_abc123",
      "video_id": "video_xyz789",
      "local_path": "/Users/you/Desktop/agnes-output/agnes-20260610-160012-001.mp4"
    }
  ],
  "still_running": [
    {
      "task_id": "task_def456",
      "video_id": "video_uvw123",
      "status": "running",
      "progress": 45
    }
  ],
  "failed": [],
  "errors": []
}
```

### 下载文件命名规则

```
agnes-YYYYMMDD-HHMMSS-001.mp4
agnes-YYYYMMDD-HHMMSS-001-01.mp4   ← 同一秒内多个文件时自动递增
```

---

## 提示词写法

**公式：**

```
[主体] + [场景/环境] + [运动方式] + [风格] + [光线] + [质量要求]
```

**文生视频示例：**

```
A luminous floating city above misty canyons at sunrise,
camera slowly panning right, cinematic realism,
soft golden light, high visual density, 4K
```

**图生视频示例：**

```
Animate the scene with gentle swaying trees and wind-blown leaves,
preserve the original composition and subjects,
soft natural lighting, smooth motion
```

**中文提示词示例（自动翻译）：**

| 中文 | 适用场景 |
|------|----------|
| `一只熊猫在竹林里缓缓走动，阳光透过竹叶，4K写实` | 动物 |
| `夜晚的城市街道，霓虹灯在雨水中倒映，慢镜头，电影感` | 都市夜景 |
| `宇宙飞船在星云中穿行，粒子特效，4K科幻风格` | 科幻 |
| `延时拍摄，云层在雪山顶快速翻涌，日出时分` | 自然延时 |
| `慢镜头，瀑布倾泻而下，水雾弥漫，超清细节` | 自然场景 |

**提示词技巧：**

- 加入**镜头运动**：`camera panning`、`slow zoom`、`orbit shot`、`push in`
- 指定**风格**：`cinematic`、`photorealistic`、`anime`、`watercolor`
- 加入**质量词**：`4K`、`ultra-detailed`、`sharp focus`、`high visual density`
- 图生视频时说明**保留内容**：`preserve original composition and subjects`

---

## 常见问题

| 错误信息 | 原因 | 解决方法 |
|----------|------|----------|
| `Missing API key` | 未设置环境变量 | `export AGNES_API_KEY="sk-..."` |
| `HTTP 401` | API Key 无效或已过期 | 前往 agnes-ai.com 重新获取 |
| `HTTP 400` | 请求参数不合法 | 检查分辨率、时长等参数 |
| `Image path does not exist` | 本地图片路径错误 | 检查路径，支持 `~` 展开 |
| `Unsupported image file type` | 图片格式不支持 | 转换为 jpg/png/webp 后重试 |
| `Timed out after 900s` | 生成时间超过等待时限 | 执行 `recover` 命令恢复下载 |
| `Video generation failed` | 服务器报告失败 | 检查提示词内容，稍后重试 |
| `Journal is empty` | 日志文件不存在或为空 | 先执行 `generate` 创建任务 |
| `ID not found in journal` | recover/status 指定的 ID 不在日志中 | 检查 task_id 或 video_id 是否正确 |
