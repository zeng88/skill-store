# Agnes Video Skill 实现计划

> 记录时间：2026-06-10
> 参照模式：`agnes-image-skill`（桌面已有）

---

## 背景与目标

基于 Agnes Video V2.0 API 实现一个 CLI skill，功能包括：
- 文字生成视频（text-to-video）
- 图片生成视频（image-to-video），支持本地路径和 URL
- 可配置视频时长（`--duration`，单位秒）
- 生成完成后自动下载视频
- 中文提示词自动翻译为英文

放置路径：`~/Desktop/agnes-video-skill/`

---

## API 关键信息（Agnes Video V2.0）

| 项目 | 值 |
|------|-----|
| Base URL | `https://apihub.agnes-ai.com` |
| 创建任务端点 | `POST /v1/video/generations` |
| 查询状态端点 | `GET /v1/videos/{task_id}` |
| 模型名称 | `agnes-video-v2.0` |
| 鉴权 | `Authorization: Bearer YOUR_API_KEY` |
| 默认分辨率 | 1152 × 768 |
| 默认帧数 | 121 帧（5秒 × 24fps + 1） |
| 默认帧率 | 24 fps |
| 视频格式 | mp4 |

> **注意**：创建端点和查询端点路径不对称——`/v1/video/generations`（单数）vs `/v1/videos/{id}`（复数），实测确认。

### 请求体格式

```json
{
  "model": "agnes-video-v2.0",
  "prompt": "...",
  "width": 1152,
  "height": 768,
  "num_frames": 121,
  "frame_rate": 24,
  "seed": 42,
  "image": "https://... 或 data:image/jpeg;base64,..."
}
```

### 时长换算

```
num_frames = int(duration_seconds × frame_rate) + 1
示例：5s × 24fps + 1 = 121 帧
```

### 响应格式

创建任务后立即返回：
```json
{
  "id": "task_xxx",
  "task_id": "task_xxx",
  "video_id": "video_yyy",
  "object": "video",
  "status": "queued"
}
```

轮询完成后：
```json
{
  "id": "task_xxx",
  "status": "completed",
  "progress": 100,
  "video_url": "https://storage.googleapis.com/...",
  "size": "1152x768",
  "seconds": "5.0",
  "completed_at": 1781060500
}
```

---

## 目录结构

```
agnes-video-skill/
├── SKILL.md
├── README.md
├── docs/
│   └── implementation-plan.md   ← 本文件
├── scripts/
│   └── agnes_video.py
└── references/
    └── api.md
```

---

## 脚本设计（`scripts/agnes_video.py`）

### 从 `agnes-image-skill` 复用的模块

| 函数 | 说明 |
|------|------|
| `get_api_key()` | 读取环境变量 API Key |
| `needs_english_translation()` | 检测非 ASCII 字符 |
| `translate_prompt()` | 调用 agnes-2.0-flash 翻译提示词 |
| `local_image_to_data_url()` | 本地图片 → base64 data URL |
| `allocate_output_path()` | 唯一文件名生成 |
| SSL 证书处理 | certifi fallback |

### 新增模块

| 函数 | 说明 |
|------|------|
| `get_json(path)` | GET 请求，用于轮询 |
| `duration_to_frames(duration, fps)` | 时长换算 |
| `poll_task(task_id, timeout, interval)` | 轮询直到完成/失败 |
| `download_video(url, output_dir)` | 下载 mp4 到本地 |
| `normalize_single_image(value)` | 单图片输入规范化 |

### CLI 子命令

```
generate   提交视频任务，轮询，可选下载
status     查询单个任务状态
```

### `generate` 参数

| 参数 | 默认值 | 说明 |
|------|--------|------|
| `--prompt` | 必填 | 视频描述 |
| `--image` | — | 输入图片（本地路径或 URL） |
| `--duration` | 5.0 | 时长（秒） |
| `--width` | 1152 | 宽度 |
| `--height` | 768 | 高度 |
| `--frame-rate` | 24 | 帧率 |
| `--seed` | — | 随机种子 |
| `--no-translate` | — | 禁用中文翻译 |
| `--download` | — | 完成后自动下载 |
| `--output-dir` | `~/Desktop/agnes-output` | 下载目录 |
| `--timeout` | 900 | 最长等待秒数 |
| `--raw` | — | 输出原始响应 |

---

## 已知问题与待改进

### 问题：轮询超时后无法恢复下载

当前流程：`提交任务 → 轮询 → 超时 → 报错退出`

如果视频生成耗时超过 `--timeout`（默认 900 秒），任务实际上可能仍在运行并最终成功，但脚本已经退出，用户无从得知 `task_id`，也无法事后下载视频。

**改进方案见下一节。**

---

## 任务日志系统设计（v2 改进）

### 设计思路

1. 每次提交任务后，立即将任务信息写入本地 JSON 日志文件
2. 轮询过程中实时更新任务状态
3. 轮询超时后，日志仍保留 `task_id`，脚本退出不丢失信息
4. 新增 `recover` 子命令：读取日志，查询所有未完成任务，若已完成则下载并回写日志

### 日志文件格式

路径默认：`~/Desktop/agnes-output/agnes-video-journal.json`

```json
{
  "task_abc123": {
    "task_id": "task_abc123",
    "video_id": "video_yyy",
    "created_at": "2026-06-10T15:30:45",
    "prompt": "A glowing city...",
    "original_prompt": "发光的城市...",
    "duration": 5.0,
    "width": 1152,
    "height": 768,
    "frame_rate": 24,
    "seed": null,
    "image_input": null,
    "status": "timeout",
    "video_url": null,
    "local_path": null,
    "completed_at": null,
    "output_dir": "~/Desktop/agnes-output",
    "last_updated": "2026-06-10T15:46:00"
  }
}
```

### 任务状态流转

```
queued → running → completed → downloaded
                ↘ failed
                ↘ timeout     ← 由 recover 命令重新拉取
```

### `recover` 子命令设计

```bash
# 检查所有未完成任务并下载
python scripts/agnes_video.py recover

# 只恢复指定任务
python scripts/agnes_video.py recover --task-id task_abc123

# 指定日志文件和下载目录
python scripts/agnes_video.py recover \
  --journal ~/Desktop/agnes-output/agnes-video-journal.json \
  --output-dir ~/Movies/agnes
```

**流程：**
1. 读取日志文件
2. 筛选 `status` 不在 `{downloaded, failed}` 的任务
3. 对每个任务 GET `/v1/videos/{task_id}`
4. 若 `completed`：下载视频，更新日志为 `downloaded`，记录 `local_path`
5. 若仍 `running/queued`：更新 `last_updated`，打印进度
6. 若 `failed`：更新日志，打印原因
7. 打印汇总报告

### generate 命令的变化

| 阶段 | 日志操作 |
|------|----------|
| 任务创建成功 | 写入初始记录，status=queued |
| 每次轮询 | 更新 status、progress、last_updated |
| 轮询成功 | 更新 status=completed，写入 video_url |
| 下载成功 | 更新 status=downloaded，写入 local_path |
| 轮询超时 | 更新 status=timeout，保留 task_id |
| 任务失败 | 更新 status=failed，写入错误信息 |

---

## 验证步骤

```bash
# 1. 文生视频（含下载）
python scripts/agnes_video.py generate \
  --prompt "A cat playing piano, cinematic, 4K" \
  --duration 5 --download

# 2. 图生视频（本地路径）
python scripts/agnes_video.py generate \
  --prompt "Animate with gentle wind" \
  --image ~/Desktop/photo.jpg --duration 3 --download

# 3. 图生视频（URL）
python scripts/agnes_video.py generate \
  --prompt "Add falling snow effect" \
  --image https://example.com/photo.jpg --duration 5 --download

# 4. 中文提示词（验证自动翻译）
python scripts/agnes_video.py generate \
  --prompt "一只熊猫在竹林里漫步，4K写实风格" --duration 5

# 5. 模拟超时后恢复下载
python scripts/agnes_video.py generate --prompt "..." --timeout 10   # 故意超时
python scripts/agnes_video.py recover                                  # 恢复

# 6. 查询单个任务
python scripts/agnes_video.py status --task-id task_xxx

# 7. 验证日志文件生成和回写
cat ~/Desktop/agnes-output/agnes-video-journal.json
```
