---
name: agnes-video-generation
description: Call Agnes AI video generation API (agnes-video-v2.0) for text-to-video and image-to-video. Use when the user asks to generate videos, animate images, create video content, or use Agnes Video V2.0 model.
---

# Agnes Video Generation

Use this skill to call Agnes AI video generation API through `https://apihub.agnes-ai.com`.

Model: `agnes-video-v2.0` — free, high-quality cinematic video generation by Sapiens AI.

## Quick Start

1. Read `references/api.md` when endpoint details, parameters, or response fields are needed.
2. Use `scripts/agnes_video.py` for all API calls instead of writing curl by hand.
3. Require an API key in `AGNES_API_KEY`, `AGNES_API_TOKEN`, or `APIHUB_AGNES_API_KEY`. Never print the key.

## Setup (one time)

```bash
export AGNES_API_KEY="sk-your-key-here"
```

## Commands

### Text-to-Video

```bash
python scripts/agnes_video.py generate \
  --prompt "A glowing city above misty clouds at sunset, cinematic, 4K" \
  --duration 5 --download
```

### Image-to-Video (local file)

```bash
python scripts/agnes_video.py generate \
  --prompt "Animate with gentle wind and falling cherry blossoms" \
  --image ~/Desktop/photo.jpg --duration 5 --download
```

### Image-to-Video (public URL)

```bash
python scripts/agnes_video.py generate \
  --prompt "Add rain and neon reflections to this scene" \
  --image https://example.com/photo.jpg --duration 5 --download
```

### Custom Duration

```bash
python scripts/agnes_video.py generate \
  --prompt "Ocean waves rolling onto a beach at golden hour" \
  --duration 3 --download
```

### Chinese Prompt (auto-translated)

```bash
python scripts/agnes_video.py generate \
  --prompt "一只熊猫在竹林里缓缓走动，4K写实风格" \
  --duration 5 --download
```

### Query Task Status

```bash
python scripts/agnes_video.py status --task-id task_abc123
```

## Workflow

- The API is asynchronous: `generate` submits a task, then polls every 5 seconds until completed (up to 15 minutes).
- For non-English prompts, auto-translation to English is applied before calling the API. Use `--no-translate` to skip.
- `--image` accepts local file paths (converted to data URL client-side) or public HTTPS URLs.
- `--duration` is converted to `num_frames` via `int(duration * frame_rate) + 1`.
- Use `--download` to automatically save the generated video to `~/Desktop/agnes-output/`.
- Use `--seed` for more reproducible outputs.

## Prompt Formula

```
[Subject] + [Scene / Environment] + [Motion] + [Style] + [Lighting] + [Quality]
```

Good example:
> A luminous city above misty canyons at sunrise, camera slowly panning right, cinematic realism, soft golden light, high visual density, 4K

## Output Handling

- On success, prints a JSON summary with `video_url`, `task_id`, and optional `local_path`.
- If `--download` is set, the video is saved as `agnes-YYYYMMDD-HHMMSS-001.mp4`.
- If a request fails, report HTTP status and provider error body without exposing the API key.

## Capabilities

| Capability | Description |
|-----------|-------------|
| Text-to-Video | Generate cinematic videos from natural language prompts |
| Image-to-Video | Animate existing images with motion and effects |
| Local Image Input | Accept local file paths, converted to data URLs client-side |
| URL Image Input | Accept public HTTPS image URLs directly |
| Configurable Duration | Specify video length in seconds via `--duration` |
| Auto Download | Save generated video locally with `--download` |
| Chinese Prompt Support | Auto-translate non-English prompts before API call |
| Task Status Query | Check status of any existing task by ID |

## Notes

- Generation typically takes 1–5 minutes depending on duration and server load.
- Default resolution is 1152×768. Use `--width` and `--height` to change.
- If the provider rejects data URLs for local images, the API will surface that error directly.
