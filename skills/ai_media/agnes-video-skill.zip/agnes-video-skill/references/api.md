# Agnes Video API Reference

Base host: `https://apihub.agnes-ai.com`

Authentication: `Authorization: Bearer YOUR_API_KEY`

Content type: `application/json`

## Video Generation

### Create Task

Endpoint: `POST /v1/video/generations`

Model: `agnes-video-v2.0`

#### Request Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `model` | string | Yes | — | Fixed as `agnes-video-v2.0` |
| `prompt` | string | Yes | — | Text description of the video |
| `width` | integer | No | 1152 | Video width in pixels |
| `height` | integer | No | 768 | Video height in pixels |
| `num_frames` | integer | No | 121 | Total frames (determines duration) |
| `frame_rate` | integer | No | 24 | Frames per second |
| `seed` | integer | No | — | Non-negative random seed |
| `image` | string | No | — | Input image URL or data URL for image-to-video |

#### Duration Calculation

```
num_frames = int(duration_seconds × frame_rate) + 1
```

Examples:
- 3 seconds @ 24fps → 73 frames
- 5 seconds @ 24fps → 121 frames
- 10 seconds @ 24fps → 241 frames

### Query Task Status

Endpoint: `GET /v1/videos/{task_id}`

Returns task status, progress, and video URL when completed.

---

## Examples

### Text-to-Video

```bash
curl https://apihub.agnes-ai.com/v1/video/generations \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "agnes-video-v2.0",
    "prompt": "A glowing city above misty clouds at sunset, cinematic, 4K",
    "width": 1152,
    "height": 768,
    "num_frames": 121,
    "frame_rate": 24
  }'
```

Initial response:
```json
{
  "id": "task_abc123",
  "status": "pending",
  "progress": 0
}
```

### Poll for Completion

```bash
curl https://apihub.agnes-ai.com/v1/videos/task_abc123 \
  -H "Authorization: Bearer YOUR_API_KEY"
```

Completed response:
```json
{
  "id": "task_abc123",
  "status": "completed",
  "progress": 100,
  "video_url": "https://storage.googleapis.com/agnes-video/output/xxx.mp4",
  "size": "1152x768",
  "seconds": "5.0"
}
```

### Image-to-Video (URL input)

```bash
curl https://apihub.agnes-ai.com/v1/video/generations \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "agnes-video-v2.0",
    "prompt": "Animate with gentle wind and falling petals",
    "width": 1152,
    "height": 768,
    "num_frames": 121,
    "frame_rate": 24,
    "image": "https://example.com/photo.jpg"
  }'
```

### Image-to-Video (Local File via CLI)

The CLI wrapper converts local files to data URLs client-side:

```bash
python scripts/agnes_video.py generate \
  --prompt "Animate with gentle wind and falling petals" \
  --image ~/Desktop/photo.jpg \
  --duration 5 \
  --download
```

---

## Polling Mechanism

Video generation is asynchronous. The workflow is:

1. POST to `/v1/videos/generations` → receive `task_id`
2. GET `/v1/videos/{task_id}` every 5 seconds
3. Check `status` field:
   - **Running**: `pending`, `queued`, `running`, `processing`, `in_progress`
   - **Completed**: `completed`, `succeeded`, `success`
   - **Failed**: `failed`, `error`, `cancelled`
4. When completed, extract `video_url` from response
5. Timeout after 15 minutes (900 seconds)

---

## Error Codes

| Code | Meaning |
|------|---------|
| `400` | Invalid request — check parameters |
| `401` | Unauthorized — check API key |
| `429` | Rate limit exceeded — retry later |
| `500` | Server error — retry later |
| `503` | Service busy — retry later |

---

## Pricing

**Free** as of June 2026.

---

## References

- Official docs: https://agnes-ai.com/doc/agnes-video-v20
