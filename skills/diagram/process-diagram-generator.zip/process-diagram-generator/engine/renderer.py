"""
Renderer - 渲染器，支持 PNG、SVG 和 Visio 导出
"""
import subprocess
import os
import shutil
import zipfile
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Optional

class Renderer:
    def __init__(self):
        self.drawio_path = self._find_drawio()

    def _find_drawio(self) -> Optional[Path]:
        """查找draw.io可执行文件"""
        # 优先使用用户明确指定的路径，便于自定义安装位置或 CI 环境调用。
        configured_path = os.environ.get('DRAWIO_PATH')
        if configured_path:
            path = Path(configured_path).expanduser()
            if path.exists() and path.is_file():
                return path

        # 尝试 macOS、Linux 和 Windows 常见安装路径。
        possible_paths = [
            Path('/Applications/draw.io.app/Contents/MacOS/draw.io'),
            Path('/Applications/Draw.io.app/Contents/MacOS/draw.io'),
            Path('/Applications/drawio.app/Contents/MacOS/drawio'),
            Path('/usr/local/bin/drawio'),
            Path('/opt/homebrew/bin/drawio'),
            Path(r'C:\Program Files\draw.io\draw.io.exe'),
            Path(r'C:\Program Files\draw.io\drawio.exe'),
        ]

        for path in possible_paths:
            if path.exists():
                return path

        # 最后从 PATH 中查找两种常见命令名；shutil.which 跨平台且不会弹出 shell。
        for command in ('drawio', 'draw.io'):
            found = shutil.which(command)
            if found:
                return Path(found)

        return None

    def _require_drawio(self) -> Path:
        """确认 draw.io 可执行文件存在，并返回其路径。"""
        if not self.drawio_path:
            raise RuntimeError(
                "未找到draw.io Desktop可执行文件，无法生成可用的.vsdx文件。\n"
                "请安装draw.io Desktop：https://github.com/jgraph/drawio-desktop/releases\n"
                "或设置DRAWIO_PATH指向可执行文件。"
            )
        return self.drawio_path

    @staticmethod
    def _validate_vsdx(vsdx_file: Path) -> None:
        """校验 VSDX 是否为结构完整且 XML 可解析的 Visio Open XML 包。"""
        if not vsdx_file.exists() or vsdx_file.stat().st_size == 0:
            raise RuntimeError(f"VSDX文件未生成或为空: {vsdx_file}")

        if not zipfile.is_zipfile(vsdx_file):
            raise RuntimeError(f"VSDX文件不是有效的ZIP包: {vsdx_file}")

        required_files = {
            '[Content_Types].xml',
            '_rels/.rels',
            'visio/document.xml',
        }
        try:
            with zipfile.ZipFile(vsdx_file, 'r') as package:
                names = set(package.namelist())
                missing = required_files - names
                if missing:
                    missing_text = '、'.join(sorted(missing))
                    raise RuntimeError(f"VSDX缺少关键包文件: {missing_text}")

                # 解析关键 XML，提前发现损坏或被截断的压缩包内容。
                for xml_name in ('[Content_Types].xml', 'visio/document.xml'):
                    ET.fromstring(package.read(xml_name))
        except zipfile.BadZipFile as exc:
            raise RuntimeError(f"VSDX压缩包损坏: {vsdx_file}") from exc
        except ET.ParseError as exc:
            raise RuntimeError(f"VSDX关键XML无法解析: {vsdx_file}") from exc

    def export_to_png(
        self,
        drawio_file: Path,
        output_file: Optional[Path] = None,
        scale: float = 2.0,
        page_index: int = 0
    ) -> Path:
        """
        导出为PNG图片

        Args:
            drawio_file: .drawio文件路径
            output_file: 输出PNG路径（默认同目录，同名.png）
            scale: 缩放比例（1.0-4.0，默认2.0高清）
            page_index: 页面索引（默认0，第一页）

        Returns:
            输出PNG文件路径
        """
        if not self.drawio_path:
            raise RuntimeError(
                "未找到draw.io可执行文件。\n"
                "请安装Draw.io Desktop：https://github.com/jgraph/drawio-desktop/releases\n"
                "或使用在线版：https://app.diagrams.net/"
            )

        if not drawio_file.exists():
            raise FileNotFoundError(f"文件不存在: {drawio_file}")

        if output_file is None:
            output_file = drawio_file.with_suffix('.png')

        # 确保输出目录存在
        output_file.parent.mkdir(parents=True, exist_ok=True)

        # 构建draw.io命令
        cmd = [
            str(self.drawio_path),
            '--export',
            str(drawio_file),
            '--output', str(output_file),
            '--scale', str(scale),
            '--format', 'png',
            '--page-index', str(page_index)
        ]

        # 执行命令
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            if result.returncode != 0:
                raise RuntimeError(f"draw.io导出失败: {result.stderr}")
        except subprocess.TimeoutExpired:
            raise RuntimeError("draw.io导出超时（30秒）")
        except FileNotFoundError:
            raise RuntimeError(f"draw.io可执行文件不存在: {self.drawio_path}")

        if not output_file.exists():
            raise RuntimeError(f"PNG文件未生成: {output_file}")

        return output_file

    def export_to_vsd(
        self,
        drawio_file: Path,
        output_file: Optional[Path] = None,
        page_index: int = 0
    ) -> Path:
        """
        导出为Visio格式（.vsdx）

        Args:
            drawio_file: .drawio文件路径
            output_file: 输出vsdx路径（默认同目录，同名.vsdx）
            page_index: 页面索引（默认0，第一页）

        Returns:
            输出vsdx文件路径
        """
        # 兼容调用方传入字符串路径，统一转换后再进行路径操作。
        drawio_file = Path(drawio_file)
        if output_file is not None:
            output_file = Path(output_file)

        drawio_path = self._require_drawio()

        if not drawio_file.exists():
            raise FileNotFoundError(f"文件不存在: {drawio_file}")

        if output_file is None:
            output_file = drawio_file.with_suffix('.vsdx')

        if output_file.suffix.lower() != '.vsdx':
            raise ValueError(f"VSDX输出文件必须使用.vsdx扩展名: {output_file}")

        # 确保输出目录存在
        output_file.parent.mkdir(parents=True, exist_ok=True)

        # 先写入同目录临时文件，避免导出失败时覆盖已有可用文件。
        temp_output = output_file.with_name(
            f'.{output_file.stem}.tmp-{os.getpid()}.vsdx'
        )
        temp_output.unlink(missing_ok=True)

        # 构建draw.io命令
        cmd = [
            str(drawio_path),
            '--export',
            str(drawio_file),
            '--output', str(temp_output),
            '--format', 'vsdx',
            '--page-index', str(page_index)
        ]

        # 执行命令
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
            if result.returncode != 0:
                detail = (result.stderr or result.stdout or '无错误详情').strip()
                raise RuntimeError(f"draw.io导出VSDX失败: {detail}")
        except subprocess.TimeoutExpired:
            raise RuntimeError("draw.io导出VSDX超时（60秒）")
        except FileNotFoundError:
            raise RuntimeError(f"draw.io可执行文件不存在: {drawio_path}")

        try:
            self._validate_vsdx(temp_output)
            temp_output.replace(output_file)
        except Exception:
            # 校验失败时不留下扩展名正确但内容不可用的文件。
            temp_output.unlink(missing_ok=True)
            raise

        return output_file

    def export_to_svg(
        self,
        drawio_file: Path,
        output_file: Optional[Path] = None,
        page_index: int = 0
    ) -> Path:
        """
        导出为SVG矢量图

        Args:
            drawio_file: .drawio文件路径
            output_file: 输出SVG路径（默认同目录，同名.svg）
            page_index: 页面索引（默认0，第一页）

        Returns:
            输出SVG文件路径
        """
        if not self.drawio_path:
            raise RuntimeError(
                "未找到draw.io可执行文件。\n"
                "请安装Draw.io Desktop：https://github.com/jgraph/drawio-desktop/releases\n"
                "或使用在线版：https://app.diagrams.net/"
            )

        if not drawio_file.exists():
            raise FileNotFoundError(f"文件不存在: {drawio_file}")

        if output_file is None:
            output_file = drawio_file.with_suffix('.svg')

        # 确保输出目录存在
        output_file.parent.mkdir(parents=True, exist_ok=True)

        # 构建draw.io命令
        cmd = [
            str(self.drawio_path),
            '--export',
            str(drawio_file),
            '--output', str(output_file),
            '--format', 'svg',
            '--page-index', str(page_index)
        ]

        # 执行命令
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            if result.returncode != 0:
                raise RuntimeError(f"draw.io导出失败: {result.stderr}")
        except subprocess.TimeoutExpired:
            raise RuntimeError("draw.io导出超时（30秒）")
        except FileNotFoundError:
            raise RuntimeError(f"draw.io可执行文件不存在: {self.drawio_path}")

        if not output_file.exists():
            raise RuntimeError(f"SVG文件未生成: {output_file}")

        return output_file
