# Process Diagram Generator Skill

AI 驱动的通用流程图生成 skill，支持把自然语言描述转换为可编辑、可导出的标准流程图。

默认生成 `.drawio` 和经过结构校验的 `.vsdx`；PNG/SVG 可按需附加导出。VSDX 需要本机安装 draw.io Desktop。

## 功能特点

- 把自然语言描述的业务、技术、项目、服务或管理流程生成标准泳道流程图
- 支持多种输出格式：.drawio、.png、.vsdx、.svg；VSDX 导出后会校验包结构和 XML
- 保留 `governance` 既有主题作为可选样式
- 支持样式微调、主题管理（可新增自定义主题）

## 快速开始

```python
import sys
sys.path.insert(0, "/path/to/process-diagram-generator")
from engine import StyleManager, FlowchartBuilder

# 定义流程节点；泳道可以是团队、角色、系统或外部参与方
nodes_data = [
    {
        "id": "1",
        "step": "提交发布申请",
        "type": "process",
        "swimlane_role": "项目团队",
        "node_role": "项目负责人",
        "output_docs": "发布申请",
        "next_steps": [{"id": "2", "condition": ""}]
    },
    # ... 更多节点
]

# 生成流程图
sm = StyleManager(theme_name="governance")
builder = FlowchartBuilder(style_manager=sm, sheet_name="示例流程", nodes_data=nodes_data)
xml = builder.generate_xml_content()
```

## 文件说明

- **SKILL.md** - 完整使用文档（推荐从这里开始）
- **example_usage.py** - 示例代码
- **references/architecture.md** - 技术架构文档（进阶阅读）
- **engine/** - 核心引擎代码

## 运行示例

```bash
cd /path/to/process-diagram-generator
python example_usage.py
```

## 注意事项

- 本 skill 是为 OpenCode/Claude Code 设计，可配合自然语言流程描述使用
- 导出 PNG/VSDX 需要安装 draw.io Desktop
- 需要 Visio 文件时必须调用 `Renderer.export_to_vsd()`；工具会拒绝无效或损坏的 VSDX 文件
- 可通过 `DRAWIO_PATH` 指定 draw.io Desktop 可执行文件路径
- `.drawio` 文件可在 https://app.diagrams.net/ 在线打开

## 许可

本 skill 可自由使用、分享、修改。
