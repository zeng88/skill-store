"""
通用流程图生成示例 - 测试 skill 核心功能
"""

from engine.style_manager import StyleManager
from engine.flowchart_builder import FlowchartBuilder
from engine.renderer import Renderer

# 示例节点数据（模拟AI解析结果）
nodes_data_example = [
    {
        "id": "1",
        "step": "提交发布申请",
        "type": "process",
        "swimlane_role": "项目团队",
        "node_role": "项目负责人",
        "output_docs": "发布申请",
        "next_steps": [{"id": "2", "condition": ""}]
    },
    {
        "id": "2",
        "step": "测试通过？",
        "type": "decision",
        "swimlane_role": "测试团队",
        "node_role": "测试负责人",
        "next_steps": [
            {"id": "3", "condition": "是"},
            {"id": "4", "condition": "否"}
        ]
    },
    {
        "id": "3",
        "step": "安排上线",
        "type": "process",
        "swimlane_role": "发布平台",
        "node_role": "发布负责人",
        "output_docs": "",
        "next_steps": [{"id": "5", "condition": ""}]
    },
    {
        "id": "4",
        "step": "返回修改",
        "type": "process",
        "swimlane_role": "项目团队",
        "node_role": "开发负责人",
        "output_docs": "",
        "next_steps": [{"id": "5", "condition": ""}]
    },
    {
        "id": "5",
        "step": "发布结果记录",
        "type": "process",
        "swimlane_role": "发布平台",
        "node_role": "系统",
        "output_docs": "发布记录",
        "next_steps": []
    }
]

print("="*60)
print("流程图生成示例 - Skill核心功能测试")
print("="*60)

# 步骤1：加载样式配置
print("\n[步骤1] 加载样式配置...")
style_manager = StyleManager(theme_name="governance")
print(f"✓ 主题: {style_manager.current_config.get('meta', {}).get('name', 'Unknown')}")

# 步骤2：应用样式调整
print("\n[步骤2] 应用样式调整...")
style_manager.override({
    'colors': {
        'decision': {
            'fill': '#FFA500'  # 橙色
        }
    },
    'edges': {
        'dashed_for_negative': True
    }
})
print("✓ 判断节点颜色: 橙色")
print("✓ 否分支连线: 虚线")

# 步骤3：生成流程图
print("\n[步骤3] 生成流程图...")
builder = FlowchartBuilder(
    style_manager=style_manager,
    sheet_name="项目发布流程",
    nodes_data=nodes_data_example
)

xml_content = builder.generate_xml_content()

# 输出到文件
output_path = "/tmp/example_flowchart.drawio"
with open(output_path, "w", encoding="utf-8") as f:
    f.write(xml_content)

print(f"✓ 流程图已生成: {output_path}")
print(f"  泳道数: {len(builder.lanes)}")
print(f"  节点数: {len(nodes_data_example)}")

# 步骤4：导出并校验可用的 VSDX 文件；需要本机安装 draw.io Desktop。
print("\n[步骤4] 导出 Visio 文件...")
renderer = Renderer()
vsdx_path = renderer.export_to_vsd(
    output_path,
    "/tmp/example_flowchart.vsdx"
)
print(f"✓ VSDX 已生成并通过结构校验: {vsdx_path}")

# 步骤5：保存自定义主题
print("\n[步骤5] 保存自定义方案...")
save_path = style_manager.save_as_theme(
    name="通用橙色判断方案",
    description="橙色判断节点，虚线表示否分支"
)
if save_path:
    print(f"✓ 主题已保存: {save_path}")

# 总结
print("\n" + "="*60)
print("✅ 所有测试通过！")
print("="*60)
print("\n核心验证：")
print("✓ 样式管理器：加载/覆盖/保存功能正常")
print("✓ 布局算法：网格化分层 + 路径碰撞检测")
print("✓ 连线计算：同行/异行 + 虚线处理")
print("✓ XML生成：完整.drawio格式")
print("\n输出文件：")
print(f"  {output_path}")
print(f"\n可导入 draw.io 打开：https://app.diagrams.net/")
