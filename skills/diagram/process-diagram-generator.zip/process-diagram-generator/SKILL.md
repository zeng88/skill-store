---
name: process-diagram-generator
description: 用于将自然语言描述的任意业务、技术或管理流程生成标准流程图，支持泳道、判断、文档节点以及 .drawio、PNG、VSDX、SVG 输出。触发词：流程图、画流程图、生成流程、创建流程图、泳道图、drawio、流程可视化、审批流程、"画一个XXX流程图"。
---

# Process Diagram Generator Skill

把自然语言描述的任意流程，生成为标准**泳道流程图**。流程可以来自业务、产品、研发、项目、服务、运营、管理等场景。输出 `.drawio`（可编辑）、`.png`（高清图）、`.vsdx`（可用的 Visio 文件）、`.svg`。

保留 `governance` 作为一个既有可选主题；也支持样式微调和主题管理，可新增自定义主题。

默认交付流程图时，同时保存可编辑的 `.drawio` 和经过校验的 `.vsdx`；PNG/SVG 按用户需要导出。若本机没有 draw.io Desktop，必须明确说明 VSDX 暂时无法生成，不能用改扩展名的方式伪造文件。

## 触发时机

用户出现下列信号时激活：
- 直接指令：「画流程图」「生成XX流程」「画一个项目发布泳道图」
- 用户希望把业务、技术、项目、服务或管理流程可视化
- 提到 drawio、泳道、审批流程、状态流转、系统交互等

## 工作原理（三步）

```
用户描述 → [Step 1] AI 解析为节点数据 → [Step 2] 引擎生成 .drawio → [Step 3] 渲染导出
```

引擎路径：`~/.claude/skills/process-diagram-generator`。调用前把该目录加入 `sys.path`：
```python
import sys
sys.path.insert(0, "/Users/<user>/.claude/skills/process-diagram-generator")
from engine import StyleManager, FlowchartBuilder, Renderer
```

## Step 1 — 把流程描述解析为节点数据

引擎不直接接受自然语言。**你的核心职责**是把用户描述的流程解析成下面的结构化节点列表，再交给引擎。

### 节点数据格式

```python
nodes_data = [
    {
        "id": "1",                       # 必填，唯一字符串标识
        "step": "提交发布申请\n（附说明）", # 必填，节点文字（\n 换行）
        "type": "process",               # 必填，"process"=矩形 | "decision"=菱形
        "swimlane_role": "项目团队",      # 必填，决定归属哪个泳道（团队/系统/角色）
        "node_role": "项目负责人",        # 必填，节点内角色标签
        "output_docs": "发布清单",        # 可选，输出文档名（无则空字符串）
        "next_steps": [                  # 必填，下游连接列表
            {"id": "2", "condition": ""} # condition 空=普通流转
        ]
    },
    {
        "id": "2",
        "step": "测试通过？",
        "type": "decision",
        "swimlane_role": "测试团队",
        "node_role": "测试负责人",
        "output_docs": "",
        "next_steps": [
            {"id": "3", "condition": "是"},
            {"id": "4", "condition": "否"}
        ]
    },
    {
        "id": "5",
        "step": "记录发布结果",
        "type": "process",
        "swimlane_role": "发布平台",
        "node_role": "系统",
        "output_docs": "",
        "next_steps": []                 # 空列表=流程终点（连到自动生成的"结束"节点）
    }
]
```

### 解析规则

- **泳道识别**：从描述中提取参与方（部门、团队、角色、系统或外部组织）作为 `swimlane_role`。泳道按节点出现顺序自动生成。
- **节点类型**：含"是否/判断/大于/匹配"等条件的设为 `decision`；动作步骤设为 `process`。
- **开始/结束节点**：**不要手动添加**，引擎会自动在最前生成"开始"、在所有 `next_steps=[]` 的节点后生成"结束"。
- **分支条件**：判断节点的每个 `next_steps` 必须带 `condition`（"是"/"否"等），普通流转留空字符串。
- **输出文档**：节点产出文件、记录、报告或其他交付物时填 `output_docs`（如"发布清单""测试报告"），会渲染为节点下方的小文档形状。

## Step 2 — 生成 .drawio

```python
from engine import StyleManager, FlowchartBuilder
from pathlib import Path

# 加载主题（示例使用既有 governance 主题；也可以替换为其他主题）
sm = StyleManager(theme_name="governance")

# 可选：样式微调（见下文"样式调整"）
sm.override({
    "edges": {"dashed_for_negative": True}
})

# 构建流程图
builder = FlowchartBuilder(
    style_manager=sm,
    sheet_name="项目发布流程",            # 标题栏文字
    nodes_data=nodes_data
)

xml = builder.generate_xml_content()
Path("项目发布.drawio").write_text(xml, encoding="utf-8")

# builder.lanes 可查看实际生成的泳道顺序
print(builder.lanes)  # 例如 ['项目团队', '测试团队', '发布平台']
```

## Step 3 — 导出为图片/Visio

导出需要本机安装 [draw.io Desktop](https://github.com/jgraph/drawio-desktop/releases)（macOS 放到 `/Applications/`）。仅生成 `.drawio` 不需要它。

如果用户要求 `.vsdx` 或 Visio 格式，**必须调用 `export_to_vsd` 并确认返回的文件存在**；不能只把 `.drawio` 文件改名为 `.vsdx`。引擎会校验 VSDX 压缩包、关键文件和 XML，校验失败会报错并清理无效文件。找不到 draw.io Desktop 时应明确提示安装，不能宣称已生成可用 VSDX。

```python
from engine import Renderer
from pathlib import Path

r = Renderer()
r.export_to_png(Path("项目发布.drawio"), Path("项目发布.png"), scale=2.0)  # 2倍高清
r.export_to_vsd(Path("项目发布.drawio"), Path("项目发布.vsdx"))            # Visio
r.export_to_svg(Path("项目发布.drawio"), Path("项目发布.svg"))             # 矢量
```

如需指定 draw.io Desktop 路径，可设置环境变量 `DRAWIO_PATH`；引擎也会自动查找 `drawio` 和 `draw.io` 命令。

`.drawio` 也可在 https://app.diagrams.net/ 在线打开编辑。

## 样式调整

用 `StyleManager.override()` 临时调整样式（不修改主题文件）。**配置键映射表**：

| 用户表达 | override 键 | 取值示例 |
|---------|------------|---------|
| 泳道宽度改成300 | `layout.swimlane_width` | `300` |
| 标题栏颜色 | `colors.layout_bar.fill` | `parse_color("浅蓝")` |
| 泳道头颜色 | `colors.swimlane_header.fill` | `"#b4bff5"` |
| 开始/结束节点颜色 | `colors.start_end.fill` | `"#d24a4a"` |
| 角色节点背景 | `colors.node_role.fill` | `"#FFFFFF"` |
| 步骤节点背景 | `colors.node_step.fill` | `"#dae8fc"` |
| 文档节点背景 | `colors.node_doc.fill` | `"#f5f5f5"` |
| 判断节点背景 | `colors.decision.fill` | `"#fff2cc"` |
| 连线颜色 | `colors.edge.stroke` | `"#000000"` |
| 开始节点形状 | `shapes.start_end` | `"rounded"` |
| 否分支用虚线 | `edges.dashed_for_negative` | `True` |
| 自定义虚线关键词 | `edges.negative_keywords` | `["否","驳回","退回"]` |

**override 示例**：
```python
sm.override({
    "colors": {"decision": {"fill": "#FFA500"}},   # 判断节点橙色
    "edges":  {"dashed_for_negative": True}        # 否分支虚线
})
```

override 后需重新调用 `builder.generate_xml_content()` 生成。`override` 是叠加式（可多次调用），`reset_overrides()` 清空回到主题原样。

## 主题管理

当前保留 `governance` 这一既有主题作为可选样式。用户可随时新增自定义主题。

| 操作 | 调用 |
|------|------|
| 列出全部主题（内置+自定义） | `sm.list_themes()` |
| 查看某主题详情 | `sm.get_theme_info("governance")` |
| 加载主题 | `sm.load_theme("governance")` 或初始化时 `StyleManager(theme_name="...")` |
| 把当前样式保存为新主题 | `sm.save_as_theme(name="我的方案", description="...")` |
| 删除自定义主题 | `sm.delete_theme("我的方案")`（内置主题受保护，不可删） |
| 清空 override 回到主题原样 | `sm.reset_overrides()` |

`save_as_theme` 会自动创建 `themes/custom/` 目录并写入 `<name>.json`，之后 `StyleManager(theme_name="<name>")` 即可加载。主题完整 JSON 字段见 `themes/README.md`。

## 颜色系统

颜色值通过 `engine.colors.parse_color()` 解析，支持多种写法：

| 写法 | 示例 |
|------|------|
| 十六进制 | `#FF0000` |
| 中文 | `红色`、`浅蓝色`、`橙色` |
| 英文 | `red`、`blue` |

```python
from engine.colors import parse_color
parse_color("橙色")   # → "#FFA500"
parse_color("#b4bff5") # → "#B4BFF5"
```

override 时颜色值可填以上任意写法，引擎内部统一经 `parse_color()` 归一。

## 端到端示例

```python
import sys
sys.path.insert(0, "/Users/<user>/.claude/skills/process-diagram-generator")
from engine import StyleManager, FlowchartBuilder, Renderer
from pathlib import Path

nodes_data = [
    {"id": "1", "step": "提交发布申请", "type": "process",
     "swimlane_role": "项目团队", "node_role": "项目负责人",
     "output_docs": "发布申请", "next_steps": [{"id": "2", "condition": ""}]},
    {"id": "2", "step": "测试通过？", "type": "decision",
     "swimlane_role": "测试团队", "node_role": "测试负责人",
     "next_steps": [{"id": "3", "condition": "是"},
                    {"id": "4", "condition": "否"}]},
    {"id": "3", "step": "安排上线", "type": "process",
     "swimlane_role": "发布平台", "node_role": "发布负责人",
     "output_docs": "", "next_steps": [{"id": "5", "condition": ""}]},
    {"id": "4", "step": "返回修改", "type": "process",
     "swimlane_role": "项目团队", "node_role": "开发负责人",
     "output_docs": "", "next_steps": [{"id": "5", "condition": ""}]},
    {"id": "5", "step": "发布结果记录", "type": "process",
     "swimlane_role": "发布平台", "node_role": "系统",
     "output_docs": "发布记录", "next_steps": []},
]

sm = StyleManager(theme_name="governance")
builder = FlowchartBuilder(style_manager=sm, sheet_name="项目发布流程", nodes_data=nodes_data)
Path("项目发布.drawio").write_text(builder.generate_xml_content(), encoding="utf-8")

renderer = Renderer()
renderer.export_to_png(Path("项目发布.drawio"), Path("项目发布.png"), scale=2.0)
renderer.export_to_vsd(Path("项目发布.drawio"), Path("项目发布.vsdx"))
```

更多示例见 `example_usage.py`。

## 故障排除

### AI 解析的流程不符合预期
- 用更明确的描述：写清部门名、步骤名。
- 用箭头符号（→）标注流转。
- 判断节点用"是否/判断/大于"等关键词。

### 样式调整不生效
- 确认 override 键拼写（见上方映射表）。
- override 后必须重新 `generate_xml_content()`。
- 手动编辑主题：`themes/governance.json` 或 `themes/custom/<name>.json`。

### PNG 导出失败
- 安装 draw.io Desktop：https://github.com/jgraph/drawio-desktop/releases
- 放到 `/Applications/`（macOS）。
- 或用 https://app.diagrams.net/ 在线打开 `.drawio` 手动导出。

### Visio 打开
- `.vsdx` 可被 Visio 2013+ 直接打开。
- 较旧版本需转换。`.drawio` 也可在 Visio 中打开。

## 技术架构

引擎内部模块结构、布局/碰撞检测算法、容错降级、样式系统机制等进阶内容，面向二次开发者，见 **[references/architecture.md](references/architecture.md)**。普通使用无需阅读。
